extends SceneTree
func _initialize():call_deferred("run")
func run():
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame
	await physics_frame
	game.front_end.new_game();game.set_physics_process(false)
	var mode=game.get_node("Inspection");var saved=game.checkpoints.latest.duplicate(true)
	mode.jump(5);assert(game.simon.inside() and game.combat.won)
	game.checkpoints.observe();assert(game.checkpoints.latest==saved)
	mode.jump(6);assert(game.torture.inside() and game.simon.won and game.inventory.has_spores)
	mode.jump(1);assert(game.feeding.inside() and not game.puzzle.solved)
	mode.leave();assert(not mode.active and not game.arrived and game.checkpoints.stage==0)
	print("PASS room jumps, unlocked access, save protection and return")
	quit()
