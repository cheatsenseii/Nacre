extends SceneTree
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	game.front_end.new_game()
	game.checkpoints.apply_save({"version":1,"stage":4,"nodes":[true,true,true],"sword":false,"events":{}})
	var c=game.combat
	# Real frame-by-frame pursuit from their spawn, with the player behind the sword screen.
	game.player.position=c.origin+Vector3(-10,0.05,-5)
	var damaged:=false
	for frame in range(1800):
		await physics_frame
		if game.health<100:damaged=true;break
	if not damaged:push_error("Enemies did not navigate to unarmed player behind screen");quit(1);return
	print("PASS: unarmed player pursued around screen and damaged, health ",game.health)
	game.paused=true;var hp: int=game.health
	for frame in range(90):await physics_frame
	if game.health!=hp:push_error("Damage while paused");quit(1);return
	game.paused=false
	c.reset_fight();c.equipped=true;c.immunity=0
	# Actual attack cycle, not direct damage invocation.
	game.player.position=c.origin+Vector3(0,0.05,-10)
	c.enemies[0].position=game.player.position+Vector3(0,0,-1.7)
	c.enemies[0].set_meta("rest",0.0)
	for frame in range(100):
		await physics_frame
		if game.health<100:break
	if game.health>=100:push_error("Armed player not hit");quit(1);return
	print("PASS: pause prevents damage and armed player takes actual attack damage")
	quit()
