extends SceneTree
func _initialize():call_deferred("run")
func run():
 var game=load("res://main.tscn").instantiate();root.add_child(game)
 await physics_frame
 await physics_frame
 game.front_end.new_game();game.arrived=true;game.set_physics_process(false);game.third_person.set_physics_process(false)
 var scares=game.scares;scares.enabled=true;scares.shadow_safe_time=0
 var found=false
 for y in range(9):
  if found:break
  for x in range(9):
   game.player.position=game.labyrinth.cell_at(Vector2i(x,y))+Vector3(0,0.05,0)
   for angle in [0,PI/2,PI,3*PI/2]:
    game.player.rotation.y=angle;game.camera.position=Vector3(0,1.4,0);game.camera.rotation=Vector3.ZERO
    if scares.try_maze_shadow():found=true;break
   if found:break
 assert(found,"No visible corridor apparition found")
 assert(scares.maze_shadow.visible)
 var hp=game.health;var time=scares.shadow_time
 scares.update_maze_shadow(1,true);assert(scares.shadow_time==time)
 var toward: Vector3=(game.player.global_position-scares.maze_shadow.global_position).normalized()
 game.player.position=scares.maze_shadow.global_position+toward*2
 scares.update_maze_shadow(0.1,false);assert(scares.maze_shadow.visible);assert(game.health==hp)
 scares.shadow_time=3;scares.maze_shadow.show();scares.enabled=false
 scares.update_maze_shadow(0.1,false);assert(not scares.maze_shadow.visible)
 scares.restore({});assert(scares.shadow_time==0)
 print("PASS: corridor placement, pause, apparition grace period, disable and reset")
 quit()
