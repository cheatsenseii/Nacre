extends SceneTree
var failures: Array[String]=[]
var checks:=0
var game: Node
var endings: Dictionary={}
func _initialize() -> void:call_deferred("run")
func check(ok: bool, message: String) -> void:
	checks+=1
	if not ok:failures.append(message);printerr("FAIL: "+message)
func freeze(node: Node) -> void:
	node.set_process(false);node.set_physics_process(false)
	for child in node.get_children():freeze(child)
func ended(key: String) -> void:endings[key]=Time.get_ticks_msec()
func tick() -> void:
	game.voice._process(1.0/60);game.feeding.update(1.0/60)
func run() -> void:
	game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	game.front_end.launch();freeze(game)
	game.checkpoints.apply_save({"version":1,"stage":1,"nodes":[false,false,false],"sword":false,"stick":true,"events":{}})
	game.scares.enabled=false
	var voice=game.voice;var meal=game.feeding;var runner=game.get_node("Bouptilop")
	game.experience._process(0.01);voice._process(0.01)
	check(voice.current=="mushroom_quest" and voice.speaker.playing,"Actual room instructions start on entry")
	meal.hp=0;meal.feeding_time=0;meal.corpse_start=meal.monster.position
	meal.update(6.1)
	check(meal.said_thanks and not meal.thanks.playing and voice.speaker.playing,"A fast kill queues thanks without speaking over the rules")
	check(meal.subtitle.text.is_empty(),"Mushroom subtitle waits for its actual line")
	meal.update(4);game.puzzle.update(3);meal.update(0.01)
	check(game.puzzle.solved and game.inventory.has_spores and meal.gift_started,"Opening and reward do not depend on the speech queue")
	check(not meal.cry.playing and voice.pending==["mushroom_thanks","mushroom_delice"],"Thanks and delight are queued in their story order")
	game.experience._process(0.01)
	check(game.experience.room=="LE REPAS" and not voice.pending.has("galleries_quest"),"Opening the door must not announce the next room's rules")
	game.scares.enabled=true
	check(not runner.try_spawn(),"Bouptilop cannot shout over an active or queued explanation")
	game.scares.enabled=false
	voice.speaker.finished.connect(ended.bind("narrator"))
	meal.thanks.finished.connect(ended.bind("thanks"));meal.cry.finished.connect(ended.bind("delice"))
	var order: Array[String]=["mushroom_quest"]
	var overlap:=false;var bad_caption:=false;var cut_thanks:=false;var gaps_ok:=true
	var moved:=false;var paused_once:=false
	# Play the original WAVs to completion: verify actual sources, not a fake delay.
	for frame in range(1800):
		await physics_frame;tick()
		var playing:=int(voice.speaker.playing)+int(meal.thanks.playing)+int(meal.cry.playing)
		overlap=overlap or playing>1
		var key: String=voice.current
		if not key.is_empty() and not order.has(key):
			order.append(key)
			if key=="mushroom_thanks":gaps_ok=gaps_ok and endings.has("narrator") and Time.get_ticks_msec()-int(endings.get("narrator",0))>=300
			if key=="mushroom_delice":gaps_ok=gaps_ok and endings.has("thanks") and Time.get_ticks_msec()-int(endings.get("thanks",0))>=300
			if key=="galleries_quest":gaps_ok=gaps_ok and endings.has("delice") and Time.get_ticks_msec()-int(endings.get("delice",0))>=300
		if meal.thanks.playing:
			bad_caption=bad_caption or voice.subtitle.visible or not meal.subtitle.text.contains("Merci")
			if not paused_once:
				paused_once=true;game.controls.open();voice._process(0.01);meal.update(0.01)
				for i in range(2):await physics_frame;tick()
				check(meal.thanks.stream_paused and not meal.subtitle.visible,"Menu pauses the mushroom voice and hides its subtitle")
				for i in range(12):await physics_frame;tick()
				check(voice.current=="mushroom_thanks" and not meal.cry.playing,"A pause cannot advance to the next sentence")
				game.controls.close();tick()
				for i in range(2):await physics_frame;tick()
				check(not meal.thanks.stream_paused and meal.subtitle.visible,"Closing the menu resumes the same sentence")
		if meal.cry.playing:
			cut_thanks=cut_thanks or not endings.has("thanks")
			bad_caption=bad_caption or voice.subtitle.visible or not meal.subtitle.text.contains("Quel délice")
			if not moved:
				moved=true;game.player.position=game.silence.origin+Vector3(0,0.05,10)
				game.experience._process(0.01)
				check(voice.pending.has("galleries_quest") and not voice.speaker.playing,"Entering the next room queues its rules until the mushroom finishes")
		if voice.current=="galleries_quest":break
	check(order==["mushroom_quest","mushroom_thanks","mushroom_delice","galleries_quest"],"Playback follows rules, thanks, delight, then the next room's rules: "+str(order))
	check(not overlap,"No two actual voice sources played simultaneously")
	check(not cut_thanks and endings.has("thanks") and endings.has("delice"),"Both mushroom WAVs finish naturally without being cut short")
	check(gaps_ok,"There is a perceptible pause between each sentence")
	check(not bad_caption,"Only the speaking character's subtitle is displayed")
	# A room-clear exclamation must not interrupt an explanation already playing.
	voice.say("victoire")
	check(voice.current=="galleries_quest" and voice.speaker.playing and voice.pending.has("victoire"),"Oh yes waits instead of cutting the current instructions")
	voice.stop_all();game.player.position=meal.center+Vector3(0,0.05,8)
	voice.say("mushroom_quest");voice.used.erase("mushroom_quest");voice.say("mushroom_quest")
	check(voice.pending.count("mushroom_quest")<=1,"Repeated room notifications cannot duplicate a line")
	voice.reset_announcements()
	meal.say("mushroom_thanks");voice._process(0.01)
	game.editor.active=true;voice._process(2);meal.update(2)
	for i in range(2):await physics_frame;tick()
	check(meal.thanks.stream_paused and not meal.subtitle.visible,"Editor suspends spatial dialogue too")
	game.editor.active=false;tick()
	for i in range(2):await physics_frame;tick()
	check(meal.thanks.playing and not meal.thanks.stream_paused,"Spatial dialogue resumes after leaving the editor")
	var toggle:=InputEventAction.new();toggle.action="voice_toggle";toggle.pressed=true
	voice._input(toggle)
	check(not voice.enabled and not meal.thanks.playing and voice.pending.is_empty(),"Turning voices off also stops the mushroom and clears queued speech")
	meal.say("mushroom_delice");meal.update(0.01)
	check(not meal.cry.playing and meal.subtitle.text.contains("Quel délice"),"Muted voice mode retains readable mushroom dialogue")
	voice.enabled=true;voice.reset_announcements();meal.say("mushroom_thanks");voice._process(0.01);meal.say("mushroom_delice")
	game.get_node("Inspection").jump(3)
	check(not meal.thanks.playing and not meal.cry.playing and voice.pending.is_empty() and meal.subtitle.text.is_empty(),"Inspection removes active and queued mushroom speech")
	game.get_node("Inspection").leave();voice.reset_announcements()
	meal.say("mushroom_thanks");voice._process(0.01);meal.say("mushroom_delice")
	game.checkpoints.apply_save({"version":1,"stage":2,"nodes":[false,false,false],"sword":false,"events":{}})
	check(not meal.thanks.playing and not meal.cry.playing and voice.pending.is_empty() and meal.gift_started,"Loading a completed room cannot replay its speech or reward")
	# Existing roaming dialogue also reserves the speaking turn in either direction.
	voice.reset_announcements();runner.voice.global_position=game.camera.global_position;runner.voice.play()
	voice.say("galleries_quest");voice._process(0.1)
	check(not voice.speaker.playing and voice.pending.has("galleries_quest"),"Narration waits for an already speaking Bouptilop")
	runner.voice.stop();voice._process(0.1)
	check(voice.speaker.playing,"Narration resumes when the roaming character stops")
	game.queue_free();await process_frame;await process_frame
	print("MUSHROOM DIALOGUE: %d checks, %d failures" % [checks,failures.size()])
	quit(0 if failures.is_empty() else 1)
