extends SceneTree
func _initialize():call_deferred("run")
func find_button(node: Node,text: String) -> Button:
	if node is Button and node.text==text:return node
	for child in node.get_children():
		var found:=find_button(child,text)
		if found!=null:return found
	return null
func run():
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame
	await physics_frame
	game.front_end.new_game();game.set_physics_process(false);game.voice.set_process(false);game.experience.set_process(false)
	var voice=game.voice
	voice.reset_announcements();voice.enabled=false;voice.say("mission")
	assert(not voice.used.has("mission") and voice.pending.is_empty())
	voice.enabled=true;voice.say("mission");assert(voice.pending.has("mission"))
	voice.say("victoire");assert(voice.pending.has("mission") and voice.pending[0]=="victoire")
	voice.pending.clear();voice.victory_cooldown=0;voice.say("victoire");assert(voice.pending.has("victoire"))
	game.checkpoints.apply_save(game.checkpoints.snapshot());assert(voice.pending.is_empty() and voice.used.is_empty())
	var inspect=game.get_node("Inspection")
	var event:=InputEventKey.new();event.keycode=KEY_F3;event.pressed=true
	inspect._input(event);assert(inspect.index==1 and game.feeding.inside())
	inspect.leave()
	game.arrived=true;game.player.position=game.puzzle.origin+Vector3(0,0.05,8);game.checkpoints.observe()
	var saved=game.checkpoints.latest.duplicate(true)
	inspect.jump(5);game.controls.open()
	find_button(game.controls.panel,"Recharger le point de reprise").pressed.emit()
	assert(not inspect.active and game.checkpoints.stage==saved.stage)
	print("PASS muted voice, repeated victory, quest queue, reset, contextual F3 and checkpoint exit")
	quit()
