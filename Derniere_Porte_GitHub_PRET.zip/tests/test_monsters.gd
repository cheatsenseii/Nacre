extends SceneTree
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	game.set_physics_process(false);game.land_in_chamber()
	var f=game.feeding;f.equipped=true
	assert(f.model.get_script().resource_path=="res://spore_creature.gd")
	game.player.position=f.center+Vector3(4,0.05,5);game.player.rotation=Vector3.ZERO
	await physics_frame
	for i in range(3):f.cooldown=0;f.attack()
	assert(f.hp==0)
	f.update(6.1);f.update(4);game.puzzle.update(3);f.update(0.1)
	assert(game.puzzle.solved and not f.monster.visible and game.inventory.has_spores)
	var c=game.combat;c.equipped=true;game.player.position=c.origin+Vector3(0,0.05,-10)
	for body in c.enemies:
		assert(body.get_node("Creature").get_script().resource_path=="res://spore_creature.gd")
		body.position=game.player.position+Vector3(0,0,-2)
		await physics_frame
		for i in range(3):c.cooldown=0;c.attack()
		assert(int(body.get_meta("hp"))==0)
	c.update(3);assert(c.won)
	print("PASS: four reference-inspired rigs, first monster death/swallow/reward and three arena kills")
	quit()
