extends SceneTree
var failed:=false
func _initialize() -> void:call_deferred("run")
func check(ok: bool,message: String) -> void:
	if not ok:failed=true;push_error(message)
func run() -> void:
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	game.front_end.new_game();game.set_physics_process(false);game.land_in_chamber()
	var f=game.feeding;var inventory=game.inventory
	f.equipped=true;f.hp=0;f.feeding_time=0;f.corpse_start=f.monster.position
	f.update(6.1)
	check(f.said_thanks and not game.puzzle.solved and not inventory.has_spores,"Thanks must precede door and gift")
	f.update(4);game.puzzle.update(1)
	f.update(0.01);check(not inventory.has_spores,"Gift before opening")
	game.puzzle.update(1);f.update(0.01)
	check(inventory.has_spores and f.gift_started and (f.cry.playing or game.voice.pending.has("mushroom_delice")),"Gift or queued dialogue missing")
	check(f.gift.visible and "Utilité inconnue" in inventory.description.text,"Mystery presentation missing")
	await physics_frame;await physics_frame
	var t: float=f.gift_time;game.paused=true;f.update(2)
	check(f.gift_time==t and (not f.cry.playing or f.cry.stream_paused),"Pause failed")
	game.paused=false;f.update(5);inventory.grant_spores()
	check(not f.gift.visible and inventory.has_spores,"One-time reward failed")
	game.checkpoints.path="user://test_gift.cfg";game.checkpoints.observe()
	inventory.restore(false);game.checkpoints.load_progress()
	check(inventory.has_spores and not f.cry.playing and f.gift_time==4,"Save restore replayed cry or lost item")
	f.update(0.1);check(not f.cry.playing,"Cry replayed after load")
	var old={"version":1,"stage":2,"nodes":[false,false,false],"sword":false,"events":{}}
	game.checkpoints.apply_save(old)
	check(inventory.has_spores and f.gift_started,"Old completed save migration")
	old.stage=1;game.checkpoints.apply_save(old)
	check(not inventory.has_spores and not f.gift_started,"New/unfinished state has premature item")
	DirAccess.remove_absolute(ProjectSettings.globalize_path(game.checkpoints.path))
	if not failed:print("PASS: thanks then door then cry/gift, inventory mystery, pause, one-time grant, save persistence and migration")
	quit(1 if failed else 0)
