extends SceneTree
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	game.front_end.new_game()
	game.set_physics_process(false)
	var menu=game.controls;var cfg:=ConfigFile.new()
	for action in menu.TITLES:
		if action=="parry":continue
		var events:=[]
		for event in InputMap.action_get_events(action):events.append(menu.encode(event))
		if action=="push":events=[{"type":"mouse","code":2}]
		cfg.set_value("touches",action,events)
	cfg.save(menu.PATH);menu.load_bindings()
	assert(InputMap.action_get_events("push")[0].button_index==2)
	assert(InputMap.action_get_events("parry")[0] is InputEventKey)
	# Recreate the whole scene to exercise automatic resume from disk.
	game.checkpoints.apply_save({"version":1,"stage":4,"nodes":[true,true,true],"sword":true,"events":{"silhouette":true}})
	game.checkpoints.observe()
	game.queue_free();await process_frame
	game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	game.front_end.continue_game()
	assert(game.combat.inside() and game.combat.equipped and game.puzzle.solved)
	assert(game.scares.fired.has("silhouette"))
	print("PASS: old remapping migration and automatic resume in fresh scene")
	quit()
