extends SceneTree
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var logo:=Image.new()
	assert(logo.load("res://branding/nacre.svg")==OK)
	logo.save_png("/workspace/scratch/3a048dc9837e/Derniere_Porte/branding/nacre.png")
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	game.set_physics_process(false)
	var design: Node
	for node in game.get_children():
		if node.get_script()!=null and node.get_script().resource_path=="res://typography.gd":design=node
	assert(design.panels>10)
	assert(design.get_node("Logo_Nacre").material_override.albedo_texture!=null)
	assert(game.hud.get_theme_font("font").resource_path=="res://fonts/Interface.ttf")
	game.puzzle.solved=true;design._process(0)
	assert(design.gate_sign.text=="PASSAGE OUVERT")
	game.feeding.equipped=true;design._process(0)
	assert(not design.stick_sign.visible)
	print("PASS: ",design.panels," classified panels, embedded logo and fonts, dynamic access sign and pickup label")
	quit()
