extends SceneTree
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	for i in range(5):await process_frame
	var front=game.front_end
	assert(front.menu_camera.current and not game.camera.current)
	assert(not game.hud.is_visible_in_tree())
	assert(front.continue_button.disabled and front.new_button.visible)
	assert(front.reference_frame.get_node("VisuelNACRE").texture!=null)
	for saved in [false,true]:
		game.checkpoints.latest={"version":1,"stage":0,"nodes":[false,false,false],"sword":false,"events":{}} if saved else {}
		front.refresh()
		for size in [Vector2i(1280,720),Vector2i(1920,1080),Vector2i(1024,768)]:
			root.size=size
			for i in range(5):await process_frame
			var previous:=Rect2()
			for button in front.menu_actions.get_children():
				if not button.visible:continue
				var rect: Rect2=button.get_global_rect()
				assert(rect.size.y>=29 and rect.size.x>=210)
				assert(rect.position.x>=0 and rect.position.y>=0)
				assert(rect.end.x<=root.get_visible_rect().size.x)
				assert(not previous.intersects(rect))
				assert(rect.end.y<=front.note.get_global_rect().position.y)
				previous=rect
	front.new_game();assert(front.confirming and front.confirmation.visible)
	front.confirmation.get_cancel_button().pressed.emit()
	await process_frame
	assert(not front.confirming and front.active)
	front.menu_actions.get_child(2).pressed.emit()
	await process_frame
	assert(game.controls.is_open and game.paused and not front.layer.visible)
	game.controls.close()
	await process_frame
	assert(front.layer.visible and front.active)
	front.menu_actions.get_child(3).pressed.emit()
	await process_frame
	assert(front.credits.visible)
	front.credits.hide()
	front.menu_actions.get_child(5).pressed.emit()
	await process_frame
	assert(game.get_node("Appearance").active)
	game.get_node("Appearance").close()
	front.continue_game();await physics_frame
	assert(game.camera.current and not front.menu_camera.current)
	assert(game.hud.is_visible_in_tree() and not front.layer.visible)
	print("PASS: image menu at 720p/1080p/4:3, disabled continue, settings, credits, appearance, confirmation and gameplay handoff")
	quit()
