extends SceneTree
func _initialize():call_deferred("run")
func run():
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame
	await physics_frame
	game.front_end.new_game();game.set_physics_process(false);game.arrived=true;game.combat.won=true
	var s=game.simon;game.player.position=s.origin+Vector3(0,0.05,-7)
	s.update(0.1);assert(s.sequence.size()==5 and s.phase=="show")
	var t: float=s.timer;game.paused=true;s.update(2);assert(s.timer==t);game.paused=false
	for i in range(4):s.update(0.9)
	assert(s.phase=="input")
	s.flash_time=0;s.choose((s.sequence[0]+1)%4);assert(s.phase=="retry" and not s.won)
	s.update(2);assert(s.phase=="show" and s.round_size==2)
	for round_index in range(4):
		while s.phase!="input":s.update(0.9)
		var count: int=s.round_size
		for i in range(count):s.flash_time=0;s.choose(s.sequence[i])
		if round_index<3:s.update(2)
	assert(s.won)
	s.update(3);assert(s.opened==1)
	game.checkpoints.stage=5;game.labyrinth.collected=[true,true,true];game.combat.equipped=true
	var data=game.checkpoints.snapshot();s.restore(false);game.checkpoints.apply_save(data)
	assert(s.won and s.opened==1)
	s.restore(false);assert(s.phase=="idle" and s.sequence.is_empty())
	print("PASS sequence demonstration, pause, retry, four rounds, gate and saved victory")
	quit()
