extends SceneTree
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	game.front_end.new_game()
	var details=game.get_node("Realism")
	var polish=details.polish
	# Switching quality repeatedly must restore the GPU-cost controls, not leave
	# high-quality shadows and particle effects enabled in Performance mode.
	for quality in [3,0,2,1,3,0]:
		polish.quality=quality;polish.apply_settings()
		assert(game.torch.shadow_enabled==(quality>0))
		assert(game.ceiling_light.shadow_enabled==(quality>0))
		assert(polish.environment.fog_enabled==(quality>0))
		assert(game.post_fx.visible==(quality>0))
		var shadows:=0
		for light in polish.spots:
			if light.shadow_enabled:shadows+=1
		assert(shadows<=quality)
		for field in details.dust_fields:assert(field.visible==(quality>=2))
	# The material pass must preserve mutable Simon pads and living membranes.
	for pad in game.simon.pads:assert(pad.material_override is StandardMaterial3D)
	for wall in game.labyrinth.shutters:
		assert(wall.material_override is ShaderMaterial)
		assert(wall.material_override!=game.labyrinth.flesh)
	assert(game.post_fx.material is ShaderMaterial)
	game.pulse_post_fx(0.7,0.3)
	assert(game.post_tension>0.0)
	var wardrobe=game.get_node("Appearance")
	wardrobe.open();wardrobe.choices.haut=1;wardrobe.changed()
	assert(wardrobe.preview!=null)
	wardrobe.close()
	# Inspection still reaches every room with the completed visual scene loaded.
	for room in range(game.get_node("Inspection").ROOMS.size()):
		game.get_node("Inspection").jump(room)
		await physics_frame
		assert(game.player.position.is_finite())
	print("PASS: Ultra/Performance switching, shadow budgets, live puzzle materials, wardrobe and seven-room inspection")
	quit()
