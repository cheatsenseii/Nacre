extends SceneTree
var failed:=false
func _initialize() -> void:call_deferred("run")
func check(ok: bool,message: String) -> void:
	if not ok:failed=true;push_error(message)
func run() -> void:
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	game.set_physics_process(false);game.land_in_chamber()
	var f=game.feeding
	game.cycle.advance(40)
	check(game.cycle.movement_factor==1 and game.cycle.toxicity==0,"Old hazards active")
	var before: Vector3=f.monster.position;f.update(3)
	check(f.monster.position==before,"Monster attacks before stick")
	game.player.position=f.center+Vector3(-2.6,0.05,8.8)
	await physics_frame;f.interact()
	check(f.equipped and not f.pickup.visible,"Stick not picked up")
	game.checkpoints.path="user://test_meal.cfg";game.checkpoints.observe()
	f.equipped=false;game.checkpoints.load_progress()
	check(f.equipped and f.hp==3,"Stick not restored")
	game.player.position=f.center+Vector3(4,0.05,5)
	game.player.rotation=Vector3.ZERO
	await physics_frame
	for i in range(3):f.cooldown=0;f.attack()
	check(f.hp==0 and f.feeding_time==0 and not game.puzzle.solved,"Three-hit death or premature opening")
	game.paused=true;f.update(4);check(f.feeding_time==0,"Pause failed")
	game.paused=false;f.update(2)
	check(f.mouth.visible and f.eyes.visible and f.monster.visible,"Feeding animation missing")
	f.update(3)
	check(f.monster.scale.x<0.5 and not game.puzzle.solved,"Monster not swallowed")
	f.update(1.1)
	f.update(4)
	check(game.puzzle.solved and f.said_thanks and not f.monster.visible,"Feeding completion failed")
	check("Merci" in f.subtitle.text or game.voice.pending.has("mushroom_thanks"),"Mushroom thanks neither spoken nor queued")
	game.puzzle.update(3);check(game.puzzle.opened==1,"Exit not opened")
	game.checkpoints.observe();game.checkpoints.load_progress()
	check(game.puzzle.solved and not f.monster.visible and not f.thanks.playing,"Completed meal restore failed")
	game.player.position=f.center+Vector3(0,0.05,-9)
	game.set_physics_process(true);Input.action_press("forward")
	for i in range(120):await physics_frame
	Input.action_release("forward")
	check(game.player.position.z<f.center.z-12 and game.player.position.y>f.center.y-0.1,"Door blocked")
	DirAccess.remove_absolute(ProjectSettings.globalize_path(game.checkpoints.path))
	if not failed:print("PASS: no spores, peaceful arrival, stick pickup/save, three hits, feeding animation, pause, thanks, completion save and walkable exit")
	quit(1 if failed else 0)
