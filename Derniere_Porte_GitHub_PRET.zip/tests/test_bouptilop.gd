extends SceneTree
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	var runner=game.get_node("Bouptilop")
	game.front_end.new_game();game.set_physics_process(false)
	game.voice.enabled=false;game.voice.reset_announcements();game.experience.set_process(false)
	game.scares.enabled=true
	assert(not runner.try_spawn(),"No surprise at the slide entrance")
	game.arrived=true
	for at in [game.puzzle.origin+Vector3(0,0.05,-30),game.labyrinth.cell_at(Vector2i(4,4)),game.combat.origin+Vector3(0,0.05,-3),game.torture.origin+Vector3(0,0.05,-3)]:
		game.player.position=at;runner.cooldown=0
		await physics_frame;await physics_frame
		assert(not runner.try_spawn() and not runner.active,"Surprise appeared outside authorised rooms")
	game.player.position=game.feeding.center+Vector3(-6,0.05,6)
	game.player.rotation=Vector3.ZERO;game.camera.rotation=Vector3.ZERO
	await physics_frame;await physics_frame
	assert(runner.try_spawn(),"Mushroom-room surprise should remain available")
	await physics_frame;await physics_frame
	assert(runner.active and runner.voice.playing)
	var start: Vector3=runner.body.position;var hp: int=game.health
	for i in range(25):await physics_frame
	assert(runner.body.position.distance_to(start)>0.15 or runner.body.velocity.length()>1)
	assert(runner.allowed_at(runner.body.position),"Runner must remain within its room")
	game.paused=true;await physics_frame
	var frozen: Vector3=runner.body.position;var age: float=runner.elapsed
	for i in range(6):await physics_frame
	assert(runner.body.position==frozen and runner.elapsed==age and runner.voice.stream_paused)
	game.paused=false
	game.player.position=game.combat.origin+Vector3(0,0.05,-3)
	await physics_frame;await physics_frame
	assert(not runner.active and not runner.voice.playing,"Leaving allowed room must stop the encounter")
	game.player.position=game.simon.origin+Vector3(0,0.05,-3)
	game.player.rotation=Vector3.ZERO;game.camera.rotation=Vector3.ZERO
	game.simon.restore(false)
	await physics_frame;await physics_frame
	runner.cooldown=0
	for i in range(4):await physics_frame
	assert(not runner.active,"Bouptilop must not interrupt Simon's sequence")
	game.simon.restore(true)
	assert(runner.try_spawn(),"Simon-room surprise should be available after the puzzle")
	await physics_frame;await physics_frame
	assert(runner.active)
	game.scares.enabled=false;await physics_frame;await physics_frame
	assert(not runner.active and not runner.voice.playing and not runner.body.visible)
	assert(game.health==hp)
	print("PASS: surprises restricted to mushroom/Simon, movement, room bounds, pause, exit cleanup, Simon protection and effects toggle")
	game.queue_free();await process_frame;await process_frame
	quit()
