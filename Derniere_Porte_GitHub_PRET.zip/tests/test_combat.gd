extends SceneTree
func _initialize() -> void:call_deferred("run")
func check(ok: bool,msg: String) -> void:
	if not ok:push_error(msg);quit(1)
func run() -> void:
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame
	game.land_in_chamber();game.puzzle.solved=true;game.silence.restore([true,true],true);game.labyrinth.collected=[true,true,true]
	var c=game.combat
	game.player.position=c.origin+Vector3(0,0.05,2)
	game.player.rotation=Vector3.ZERO
	Input.action_press("forward")
	for i in range(100):await physics_frame
	Input.action_release("forward")
	check(c.inside(),"Room entry blocked")
	game.set_physics_process(false)
	check(not c.attack(),"Unarmed attack active")
	var pos: Vector3=c.enemies[0].position;c.update(1)
	check(c.enemies[0].position==pos,"Enemy woke before sword")
	game.player.position=c.origin+Vector3(-7.5,0.05,-5)
	await physics_frame
	c.interact();check(not c.equipped,"Sword taken through wall")
	game.player.position=c.origin+Vector3(-10,0.05,-3.4)
	await physics_frame
	c.interact();check(c.equipped and not c.pickup.visible,"Sword pickup failed")
	game.player.position=c.origin+Vector3(0,0.05,-10)
	var enemy=c.enemies[0]
	enemy.position=game.player.position+Vector3(0,0,-2)
	await physics_frame
	c.attack();check(int(enemy.get_meta("hp"))==2,"Sword failed to hit")
	c.attack();check(int(enemy.get_meta("hp"))==2,"Cooldown bypass")
	c.cooldown=0;game.player.rotation.y=PI;c.attack()
	check(int(enemy.get_meta("hp"))==2,"Sword hits behind player")
	game.player.rotation.y=0
	enemy.position=game.player.position+Vector3(0,0,-1.5)
	enemy.set_meta("windup",0.1);enemy.set_meta("rest",0.0)
	await physics_frame
	c.update(0.11);check(c.health==82,"Enemy damage failed")
	var health: int=c.health;game.paused=true;c.update(4)
	check(c.health==health,"Paused fight deals damage")
	game.paused=false;c.health=10;c.immunity=0
	enemy.set_meta("windup",0.1);c.update(0.11)
	check(game.death.active and c.health==0,"Combat death sequence missing")
	game.death.update(3)
	check(c.health==100 and c.equipped and int(enemy.get_meta("hp"))==3,"Door return failed")
	game.player.position=c.origin+Vector3(0,0.05,-10)
	for body in c.enemies:
		body.position=game.player.position+Vector3(0,0,-2)
		await physics_frame
		for j in range(3):c.cooldown=0;c.attack()
		check(int(body.get_meta("hp"))==0,"Enemy cannot be killed")
	c.update(3);check(c.won and c.opened==1,"Victory gate failed")
	game.player.position=c.origin+Vector3(0,0.05,-26)
	game.set_physics_process(true);Input.action_press("forward")
	for i in range(140):await physics_frame
	Input.action_release("forward")
	check(game.player.position.z<c.origin.z-30 and game.player.position.y>c.origin.y-0.1,"Exit blocked or missing floor")
	print("PASS: entry, sleeping enemies, occluded sword, pickup, directional melee, cooldown, damage, pause, death checkpoint, three kills and exit")
	quit()
