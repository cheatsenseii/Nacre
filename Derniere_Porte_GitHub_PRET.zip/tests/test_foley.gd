extends SceneTree
func _initialize() -> void: call_deferred("run")
func freeze_scripts(node: Node) -> void:
	node.set_process(false); node.set_physics_process(false)
	for child in node.get_children(): freeze_scripts(child)
func run() -> void:
	var game=load("res://main.tscn").instantiate(); root.add_child(game)
	await physics_frame
	await physics_frame
	game.front_end.new_game(); freeze_scripts(game)
	game.audio_mix._process(0.01)
	var f=game.get_node("Foley")
	for surface in ["dalle","eau","organique"]:
		var unique:=[]
		for i in range(6):
			var sound=f.next_step(surface)
			assert(not unique.has(sound),"Six distinct footsteps before reusing a take")
			unique.append(sound)
		assert(f.next_step(surface)!=unique.back(),"No repeat between shuffled sets")
	game.player.position=Vector3(0,0.05,2)
	for i in range(8):
		game.player.velocity=Vector3(0,-2,0); game.player.move_and_slide(); await physics_frame
	f.last=game.player.position-Vector3(1.2,0,0); f.grounded=true; f._physics_process(0.016)
	assert(f.step.playing and f.banks["dalle"].has(f.step.stream),"Dry floor must trigger a tile footstep")
	var count: int=f.variation
	for i in range(100): f._physics_process(0.016)
	assert(f.variation==count,"Standing still must not trigger footsteps")
	for puddle in get_nodes_in_group("nacre_wet_surface"):
		assert(f.surface_at(puddle.global_position)=="eau","Visible water must sound wet")
	game.arrived=true; game.player.position=game.labyrinth.origin+Vector3(0,0.05,-2)
	assert(f.surface_at(game.player.position)=="organique","Labyrinth must have organic footsteps")
	f.play_step("organique",2); var walking: float=f.step.volume_db
	game.actions.crouched=true; f.play_step("organique",2)
	assert(f.step.volume_db<walking-8,"Crouching must sound quieter")
	game.actions.crouched=false
	f.last=game.player.position-Vector3(10,0,0); f._physics_process(0.016)
	assert(not f.step.playing and f.distance==0,"Inspection teleports must not emit footsteps")
	game.paused=true; f.play_step("dalle",2); f._physics_process(0.016)
	assert(not f.step.playing and not f.motion.playing,"Pause must stop character sounds")
	game.paused=false; f.volume=-40; f._physics_process(0.016)
	assert(not f.motion.playing,"Existing character mute must be honoured")
	game.queue_free(); await process_frame; await process_frame
	print("PASS footsteps: 18 unique takes, surfaces, distance, crouch, pause, teleport and mute")
	quit()
