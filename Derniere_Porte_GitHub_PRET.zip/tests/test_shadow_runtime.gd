extends SceneTree
func _initialize() -> void: call_deferred("run")
func run() -> void:
	var game=load("res://main.tscn").instantiate(); root.add_child(game)
	await physics_frame; await physics_frame
	game.front_end.launch(); game.voice.enabled=false
	game.checkpoints.apply_save({"version":1,"stage":3,"nodes":[true,true,false],"sword":false,"stick":true,"spores":true,"events":{}})
	await physics_frame; await physics_frame
	var scare=game.scares; var maze=game.labyrinth; var nav=scare.shadow_nav
	scare.enabled=true; scare.shadow_safe_time=0; scare.shadow_stage=2
	var spawn:=Vector3.ZERO
	for direction in [Vector2i.LEFT,Vector2i.RIGHT,Vector2i.DOWN]:
		var next: Vector2i=Vector2i(4,0)+direction
		if maze.links.has(maze.edge(Vector2i(4,0),next)) and nav.free_at(nav.center(next)): spawn=nav.center(next); break
	if not scare.start_shadow(spawn,2): printerr("FAIL runtime spawn"); quit(1); return
	for i in range(420):
		await physics_frame
		if game.death.active: break
	if not game.death.active or game.health!=0: printerr("FAIL runtime capture"); quit(1); return
	for i in range(240):
		await physics_frame
		if not game.death.active: break
	if game.death.active or game.health!=100 or game.paused or maze.collected!=[true,true,false]:
		printerr("FAIL runtime checkpoint return"); quit(1); return
	if scare.shadow_safe_time<=0 or game.player.position.distance_to(nav.center(Vector2i(4,0)))>0.2:
		printerr("FAIL runtime respawn protection"); quit(1); return
	game.queue_free(); await process_frame; await process_frame
	print("PASS shadow runtime: live physics pursuit, death animation, automatic checkpoint return and protection")
	quit()
