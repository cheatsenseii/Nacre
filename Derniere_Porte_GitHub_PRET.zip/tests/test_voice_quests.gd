extends SceneTree

func _initialize() -> void:
 call_deferred("run")

func run() -> void:
 var game=load("res://main.tscn").instantiate()
 root.add_child(game)
 await physics_frame
 await physics_frame
 var voice=game.voice
 for key in ["mission","mushroom_quest","galleries_quest","labyrinth_quest","combat_quest"]:
  assert(voice.captions.has(key),"Missing caption: "+key)
  assert(voice.clips.has(key) and voice.clips[key]!=null,"Missing clip: "+key)
 game.front_end.new_game()
 game.experience._process(0.1)
 assert(voice.pending.has("mission"),"Mission announcement not queued")
 game.arrived=true
 game.experience.room="LA DESCENTE"
 game.experience._process(0.1)
 assert(voice.pending.has("mushroom_quest"),"Room quest announcement not queued")
 voice._process(0.1)
 assert(voice.subtitle.visible or voice.speaker.playing,"Voice did not start")
 print("PASS quest clips, captions, room announcements and playback")
 quit()
