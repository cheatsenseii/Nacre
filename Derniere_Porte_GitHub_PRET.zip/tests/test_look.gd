extends SceneTree
func _initialize():call_deferred("run")
func run():
 var game=load("res://main.tscn").instantiate();root.add_child(game)
 await physics_frame
 await physics_frame
 var look=game.get_node("Appearance")
 look.open();assert(look.active and game.paused and look.preview.visible)
 look.choices.haut=1;look.choices.barbe=false;look.choices.sac_visible=false;look.changed()
 assert(not look.preview.get_node("Sac_detaille").visible)
 assert(not game.third_person.avatar.get_node("Sac_detaille").visible)
 var cfg=ConfigFile.new();assert(cfg.load("user://apparence.cfg")==OK);assert(cfg.get_value("look","haut")==1)
 look.close();assert(game.paused)
 game.front_end.new_game();game.controls.open();look.open();look.close();assert(game.controls.is_open and game.paused)
 game.controls.close();assert(not game.paused)
 print("PASS appearance preview, live updates, saved settings and pause return")
 quit()
