extends SceneTree

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var game=load("res://main.tscn").instantiate()
	root.add_child(game)
	await physics_frame
	await physics_frame
	game.front_end.launch()
	game.arrived=true
	assert(game.voice.captions["arrivee"]=="WOW ALORS ÇA C'EST DU CHAMPIGNON !!!","Mushroom arrival line missing")
	assert(game.voice.clips["arrivee"]!=null,"Mushroom arrival audio missing")
	game.player.position=game.labyrinth.cell_at(Vector2i(4,4))+Vector3(0,0.05,0)
	game.player.rotation=Vector3.ZERO
	var scares=game.scares
	scares.shadow_safe_time=0
	var maze=game.labyrinth
	maze.collected=[false,false,false]
	scares.shadow_stage=-1
	scares.update_maze_shadow(0.1,false)
	assert(scares.shadow_stage==0,"Shadow baseline stage missing")
	maze.collected[0]=true
	scares.update_maze_shadow(0.1,false)
	assert(scares.shadow_stage==1 and scares.shadow_time>0,"Shadow did not react to first node")
	var first_volume: float=scares.shadow_sound.volume_db
	maze.collected[1]=true
	scares.update_maze_shadow(0.1,false)
	assert(scares.shadow_stage==2 and scares.shadow_sound.volume_db>first_volume,"Shadow did not intensify at second node")
	var second_distance: float=scares.shadow_follow_target(2).distance_to(game.player.global_position)
	maze.collected[2]=true
	scares.update_maze_shadow(0.1,false)
	assert(scares.shadow_stage==3 and scares.shadow_sound.volume_db>first_volume,"Shadow did not intensify at third node")
	var third_distance: float=scares.shadow_follow_target(3).distance_to(game.player.global_position)
	assert(third_distance<second_distance,"Shadow leash did not shorten")
	game.arrived=false;game.sliding=false
	game.player.position=game.top_npc.global_position+Vector3(0,0.05,1.0)
	assert(game.top_npc.near_player(),"Top NPC is not interactable")
	assert(game.top_npc.interact() and game.top_npc.talked,"Top NPC dialogue did not trigger")
	assert(game.top_npc.dialogue.text.find("attendu")>=0,"Top NPC dialogue is missing")
	var interaction := InputEventAction.new()
	interaction.action="interact";interaction.pressed=true
	game._unhandled_input(interaction)
	assert(not game.sliding,"Repeated NPC interaction launched slide")
	game.inventory.grant_spores()
	game.inventory.resonate(2,false)
	assert(game.inventory.resonance==2,"Spore resonance missing")
	game.inventory.restore(true)
	assert(game.inventory.resonance==3,"Saved nodes did not restore resonance")
	game.inventory.restore(false)
	assert(game.inventory.description.text.contains("Aucun objet"),"Empty inventory retained clue")
	game.arrived=true
	game.player.position=maze.cell_at(Vector2i(4,4))+Vector3(0,0.05,0)
	scares.shadow_stage=0
	scares.update_maze_shadow(0.1,true)
	assert(scares.shadow_stage==0,"Shadow escalated while frozen")
	game.arrived=false
	game.player.position=Vector3(0,0,-2.5)
	game._unhandled_input(interaction)
	assert(game.sliding,"Entrance interaction did not launch slide")
	print("PASS: progressive labyrinth shadow and despair NPC")
	quit()
