extends SceneTree
var checks := 0
var failures: Array[String] = []
func _initialize() -> void: call_deferred("run")
func verify(ok: bool, message: String) -> void:
	checks += 1
	if not ok: failures.append(message); printerr(message)
func freeze_scripts(node: Node) -> void:
	node.set_process(false); node.set_physics_process(false)
	for child in node.get_children(): freeze_scripts(child)
func run() -> void:
	var legacy:=ConfigFile.new(); legacy.set_value("sound","volume",-40.0); legacy.save("user://bruitages.cfg")
	var game=load("res://main.tscn").instantiate(); root.add_child(game)
	await physics_frame
	await physics_frame
	game.front_end.new_game(); freeze_scripts(game)
	var mix=game.audio_mix
	verify(mix.levels["Pas"]==0 and game.get_node("Foley").volume>-40,"Legacy footstep mute must migrate to the visible slider")
	mix._process(0.01)
	for player in mix.voice_sources: player.stop(); player.stream_paused=false
	verify(mix.pool.size()==8,"One-shot sources must be bounded")
	verify(game.voice.speaker.bus=="Voix" and game.feeding.cry.bus=="Voix" and game.top_npc.voice.bus=="Voix","All dialogue must use the voice bus")
	verify(game.simon.speaker.bus=="Bruitages" and game.get_node("Foley").step.bus=="Pas","Simon notes stay dry; footsteps use their own control")
	verify(AudioServer.get_bus_send(AudioServer.get_bus_index("Decor"))=="Bruitages","World effects must follow the effects volume")
	var master_count:=AudioServer.get_bus_effect_count(0)
	var bus_count:=AudioServer.bus_count
	mix.install_buses()
	verify(AudioServer.bus_count==bus_count and AudioServer.get_bus_effect_count(0)==master_count,"Reload must not duplicate buses or effects")
	mix.levels["Pas"]=0; mix.quiet_mode=true; mix.apply_levels(); mix.save_settings()
	verify(AudioServer.is_bus_mute(AudioServer.get_bus_index("Pas")),"Zero footstep volume must be truly silent")
	verify(AudioServer.is_bus_effect_enabled(0,mix.night_index),"Night compressor must be switchable")
	verify(AudioServer.get_bus_volume_db(AudioServer.get_bus_index("Apparitions"))==-6,"Night mode must reduce scare intensity")
	mix.levels["Pas"]=100; mix.quiet_mode=false; mix.load_settings(); mix.apply_levels()
	verify(mix.levels["Pas"]==0 and mix.quiet_mode,"Audio settings must persist")
	for i in range(mix.CONTROL_BUSES.size()): mix.levels[mix.CONTROL_BUSES[i]]=mix.DEFAULTS[i]
	mix.quiet_mode=false; mix.apply_levels()
	game.feeding.thanks.global_position=game.camera.global_position
	game.feeding.thanks.play()
	mix.update_mix(0.5)
	verify(mix.music_duck<=-10 and mix.ambience_duck<=-7,"NPC dialogue must duck the music and ambience")
	game.feeding.thanks.stop(); mix.update_mix(3)
	verify(is_zero_approx(mix.music_duck),"Music must recover after dialogue")
	game.voice.speaker.stream=game.voice.clips["mission"]; game.voice.speaker.play(); mix.update_mix(0.5)
	verify(mix.music_duck<=-10,"Player dialogue must also duck music")
	mix.levels["Voix"]=0; mix.apply_levels(); mix.update_mix(3)
	verify(is_zero_approx(mix.music_duck),"Muted voices must not pump the music")
	mix.levels["Voix"]=100; mix.apply_levels(); game.voice.speaker.stop()
	game.atmosphere.music.stream_paused=true; mix.update_mix(1)
	verify(game.atmosphere.music.stream_paused,"Mixer must respect the music toggle")
	game.atmosphere.music.stream_paused=false
	mix.reset_transients()
	var at: Vector3=game.camera.global_position+Vector3(0,0,-1)
	var first=mix.play_at("hit",at)
	verify(first!=null and first.playing,"Combat cue must start")
	var old_stream=first.stream
	verify(mix.play_at("hit",at)==null,"Identical events in one frame must not pile up")
	mix.cooldowns.clear(); first.stop()
	var second=mix.play_at("hit",at)
	verify(second!=null and second.stream!=old_stream,"Consecutive hits must use different takes")
	await physics_frame
	await process_frame
	game.paused=true; mix._process(0.01)
	verify(second.stream_paused and mix.play_at("hurt",at)==null,"Pause must freeze active effects and refuse new ones")
	game.paused=false; mix._process(0.01)
	verify(not second.stream_paused,"Effects must resume with the game")
	game.editor.active=true; mix._process(0.01)
	verify(second.stream_paused,"Editor must freeze effects")
	game.editor.active=false; mix._process(0.01)
	mix.reset_transients()
	for i in range(8): mix.cooldowns.clear(); mix.play_at("hit",at)
	mix.cooldowns.clear()
	verify(mix.play_at("drip",at)==null and mix.pool.size()==8,"Ambience must not steal a busy combat source")
	mix.reset_transients()
	for player in mix.pool: verify(not player.playing,"Checkpoint must stop every stale effect")
	mix.cooldowns.clear(); var spatial=mix.play_at("drip",at)
	game.camera.global_position=Vector3(70,4,70); spatial.global_position=Vector3(70,4,66)
	var wall:=StaticBody3D.new(); wall.position=Vector3(70,4,68)
	var collision:=CollisionShape3D.new(); var shape:=BoxShape3D.new(); shape.size=Vector3(4,4,0.4); collision.shape=shape
	wall.add_child(collision); game.add_child(wall)
	await physics_frame
	mix.update_occlusion()
	verify(spatial.attenuation_filter_cutoff_hz==1900,"Sounds behind a wall must be muffled")
	wall.collision_layer=0; await physics_frame; mix.update_occlusion()
	verify(spatial.attenuation_filter_cutoff_hz==9000,"Unobstructed sounds must regain clarity")
	mix.reset_transients(); game.queue_free(); await process_frame; await process_frame
	if failures.is_empty(): print("PASS audio mix: %d checks (routing, persistence, dialogue, pause, pool, occlusion)" % checks)
	quit(0 if failures.is_empty() else 1)
