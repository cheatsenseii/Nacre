extends SceneTree
var failed:=false
func _initialize() -> void:call_deferred("run")
func check(ok: bool,msg: String) -> void:
	if not ok:failed=true;push_error(msg)
func run() -> void:
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	game.front_end.new_game();game.land_in_chamber();game.player.position=game.puzzle.origin+Vector3(8,0.05,0)
	await physics_frame;await physics_frame
	var third=game.third_person
	check(third.avatar.visible and game.camera.position.z>2,"No third-person camera")
	var wall=game.box(game.player.position+Vector3(0,1.5,2),Vector3(4,3,0.3),Color.WHITE)
	await physics_frame;await physics_frame
	check(third.camera_distance<1.9,"Camera passed through wall")
	wall.queue_free();await physics_frame
	for i in range(50):await physics_frame
	check(third.camera_distance>3,"Camera did not recover")
	game.player.position=game.feeding.center+Vector3(-2.6,0.05,8.8)
	await physics_frame;await physics_frame
	game.feeding.interact();check(game.feeding.equipped,"Pickup uses camera distance")
	game.player.position=game.feeding.center+Vector3(4,0.05,5);game.player.rotation=Vector3.ZERO;game.camera.rotation=Vector3.ZERO
	await physics_frame;await physics_frame
	game.feeding.cooldown=0;game.feeding.attack()
	check(game.feeding.hp==2,"Stick cannot reach from third person")
	check(not game.feeding.stick.visible and not game.actions.hands.visible,"First person meshes visible")
	game.checkpoints.apply_save({"version":1,"stage":4,"nodes":[true,true,true],"sword":true,"events":{}})
	game.player.position=game.combat.origin+Vector3(0,0.05,-10)
	var body=game.combat.enemies[0];body.position=game.player.position+Vector3(0,0,-2)
	await physics_frame;await physics_frame
	game.combat.cooldown=0;game.combat.attack()
	check(int(body.get_meta("hp"))==2,"Sword cannot reach from third person")
	check(third.blade.visible,"Equipped blade not on avatar")
	game.editor.active=true;third._physics_process(0);check(not third.avatar.visible,"Editor hides avatar")
	game.editor.active=false
	if not failed:print("PASS: visible avatar, camera collision/recovery, stick pickup, melee reach and held sword")
	quit(1 if failed else 0)
