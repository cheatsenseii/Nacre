extends SceneTree
var checks:=0
var failures: Array[String]=[]
var game: Node
func _initialize() -> void:call_deferred("run")
func check(ok: bool,message: String) -> void:
	checks+=1
	if not ok:failures.append(message);printerr("FAIL: "+message)
func freeze(node: Node) -> void:
	node.set_process(false);node.set_physics_process(false)
	for child in node.get_children():freeze(child)
func progress(stage: int) -> Dictionary:
	return {"version":1,"stage":stage,"nodes":[stage>=4,stage>=4,stage>=4],"sword":stage>=4,"stick":stage>=1,"spores":stage>=2 and stage<7,"events":{},"simon_done":stage>=6,"torture_captured":stage>=7,"torture_doses":3 if stage>=7 else 0}
func run() -> void:
	game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	game.front_end.launch();freeze(game);game.voice.enabled=false;game.voice.reset_announcements()
	var death=game.death;var door=death.door;var saves=game.checkpoints
	# A lethal mushroom-room attack now uses the common death and return sequence.
	saves.apply_save(progress(1));game.player.position=game.feeding.center+Vector3(4,0.05,4.4)
	await physics_frame
	game.health=8;game.feeding.windup=0.05;game.feeding.immunity=0;game.feeding.update(0.1)
	check(death.active and game.health==0 and game.paused,"Mushroom monster causes a real death before respawn")
	check(death.title.text=="TU ES MORT","Creature deaths have a generic death title, not the shadow's caption")
	check(death.resume_data.return_door==1 and death.resume_data.stick,"Death remembers the arrival doorway and the collected stick")
	death.update(3)
	check(not death.active and game.health==100 and game.feeding.equipped,"Mushroom-room return restores health and keeps the stick")
	check(game.player.position.distance_to(game.feeding.center+Vector3(0,0.05,8))<0.01,"Mushroom-room death returns to the slide arrival")
	check(game.feeding.immunity>=2 and game.feeding.hp==3,"The unfinished monster fight restarts with a short safe interval")
	# Combat must return at the last crossed door rather than calling an instant local reset.
	saves.apply_save(progress(4));game.player.position=game.combat.origin+Vector3(0,0.05,-10)
	var enemy: CharacterBody3D=game.combat.enemies[0]
	enemy.position=game.player.position+Vector3(0,0,-1.5);enemy.set_meta("windup",0.05);enemy.set_meta("rest",0.0)
	game.health=18;game.combat.immunity=0
	await physics_frame;game.combat.update(0.1)
	check(death.active and game.health==0,"Combat attack also enters the common death sequence")
	check(death.resume_data.return_door==4 and death.resume_data.sword,"Combat death keeps the sword and the combat entrance")
	death.update(3)
	check(game.health==100 and game.combat.equipped and not game.paused,"Combat return restores health and controls")
	check(game.player.position.distance_to(game.combat.origin+Vector3(0,0.05,-2))<0.01,"Combat return is two metres inside its entrance")
	check(game.labyrinth.collected==[true,true,true] and game.inventory.has_spores,"Earlier nodes and collected spores remain acquired")
	# Opening a door without crossing it must not move the return point forward.
	saves.apply_save(progress(1));game.puzzle.solved=true;saves.observe()
	check(saves.stage==2 and saves.latest.return_door==1,"Opening the mushroom door does not count as crossing it")
	game.health=0;game._physics_process(0.01)
	check(death.active and death.resume_data.return_door==1,"Any zero-health death uses the actual previous doorway")
	death.update(3)
	check(game.player.position.distance_to(game.feeding.center+Vector3(0,0.05,8))<0.01 and game.puzzle.solved,"A completed challenge stays open without spawning in the next room")
	# Track actual passage in both directions and keep the correct side and facing.
	saves.apply_save(progress(3))
	game.labyrinth.collected=[true,false,true]
	game.player.position=game.labyrinth.origin+Vector3(0,0.05,-0.3);door.last_position=game.player.position
	game.player.position.z+=0.6;saves.observe()
	check(door.index==3 and door.backwards,"Crossing back into the silence room remembers the maze doorway")
	check(saves.latest.return_door==3 and saves.latest.return_back,"The doorway side is saved alongside progression")
	var returned: Dictionary=saves.latest.duplicate(true)
	game.health=0;game._physics_process(0.01);death.update(3)
	check(game.player.position.distance_to(game.labyrinth.origin+Vector3(0,0.05,2))<0.01,"Backtracking death returns on the side just entered")
	check(is_equal_approx(game.player.rotation.y,PI),"Backtracking return faces away from the doorway into the room")
	check(game.labyrinth.collected==[true,false,true] and game.silence.solved,"Partial maze progress and the silence door remain unchanged")
	saves.apply_save(progress(1));saves.apply_save(returned)
	check(door.backwards and game.player.position.distance_to(game.labyrinth.origin+Vector3(0,0.05,2))<0.01,"Loading a saved return point restores its side")
	game.player.position=game.labyrinth.origin+Vector3(0,0.05,0.3);door.last_position=game.player.position
	game.player.position.z-=0.6;saves.observe()
	check(door.index==3 and not door.backwards,"Crossing forward again updates the saved side")
	var before: int=door.index
	game.paused=true;game.player.position=game.combat.origin+Vector3(0,0.05,-2);door.observe()
	check(door.index==before,"A paused game cannot record a new doorway")
	game.paused=false;door.seed_from_position()
	# Every canonical return spot must have a floor and enough standing clearance.
	game.player.position=game.feeding.center+Vector3(8,0.05,8)
	var shape:=CapsuleShape3D.new();shape.radius=0.3;shape.height=1.7
	for index in range(8):
		door.restore(index,false);var at: Vector3=door.destination()
		var ray:=PhysicsRayQueryParameters3D.create(at+Vector3.UP,at-Vector3.UP,1,[game.player.get_rid()])
		var floor: Dictionary=game.get_world_3d().direct_space_state.intersect_ray(ray)
		var query:=PhysicsShapeQueryParameters3D.new();query.shape=shape;query.collision_mask=1;query.exclude=[game.player.get_rid()]
		query.transform=Transform3D(Basis.IDENTITY,at+Vector3.UP*0.9)
		check(not floor.is_empty() and floor.normal.y>0.8 and game.get_world_3d().direct_space_state.intersect_shape(query,1).is_empty(),"Safe floor and standing clearance at door "+str(index))
	# Old saves remain compatible; bogus door coordinates cannot be introduced.
	saves.apply_save(progress(3));check(door.index==3 and not door.backwards,"Legacy saves infer a safe previous door")
	var invalid:=progress(3);invalid.return_door=9;check(not saves.valid(invalid),"Out-of-range door is rejected")
	invalid=progress(2);invalid.return_door=3;check(not saves.valid(invalid),"Unreached future door is rejected")
	invalid=progress(3);invalid.return_back="yes";check(not saves.valid(invalid),"Invalid direction type is rejected")
	invalid=progress(1);invalid.return_door=1;invalid.return_back=true;check(not saves.valid(invalid),"Cannot respawn backwards into the slide")
	# Inspection remains independent of the user's real saved return point.
	saves.observe();var original: Dictionary=saves.latest.duplicate(true)
	var inspection=game.get_node("Inspection");inspection.jump(4)
	game.health=0;game._physics_process(0.01);death.update(3);saves.observe()
	check(inspection.active and game.combat.inside() and saves.latest==original,"Inspection death stays in its room without changing the real save")
	inspection.leave();check(saves.latest==original,"Leaving inspection restores the real return point")
	game.queue_free();await process_frame;await process_frame
	print("DOOR RETURN: %d checks, %d failures" % [checks,failures.size()])
	quit(0 if failures.is_empty() else 1)
