extends SceneTree
var failures: Array[String]=[]
var checks:=0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, message: String) -> void:
	checks+=1
	if not ok: failures.append(message); printerr("FAIL: "+message)
func freeze_scripts(node: Node) -> void:
	node.set_process(false); node.set_physics_process(false)
	for child in node.get_children(): freeze_scripts(child)
func old_save(stage: int=2) -> Dictionary:
	return {"version":1,"stage":stage,"nodes":[false,false,false],"sword":false,"stick":true,"spores":true,"events":{}}
func settle(game: Node, at: Vector3) -> void:
	game.teleport_player(at)
	for i in range(15):
		game.player.velocity=Vector3(0,-2,0); game.player.move_and_slide(); await physics_frame
	game.player.velocity=Vector3.ZERO
func aim_at(game: Node, target: Vector3) -> void:
	game.camera.global_position=game.player.position+Vector3(0,1.6,0.25)
	game.camera.look_at(target)
func walk_to(game: Node, point: Vector3) -> bool:
	for i in range(700):
		var direction: Vector3=point-game.player.position; direction.y=0
		if direction.length()<0.16: game.player.velocity=Vector3.ZERO; return true
		game.player.velocity=direction.normalized()*6; game.player.velocity.y=-2
		game.player.move_and_slide(); await physics_frame
	return false
func run() -> void:
	Engine.physics_ticks_per_second=120
	var game=load("res://main.tscn").instantiate(); root.add_child(game)
	await physics_frame; await physics_frame
	game.front_end.launch(); freeze_scripts(game)
	game.voice.enabled=false
	var room=game.silence
	game.checkpoints.apply_save(old_save())
	check(room.closed==[false,false] and not room.solved,"Old stage-two saves must receive the new challenge")
	check("vannes" in game.experience.current_goal()[1],"Room objective must explain the valves")
	check(game.voice.clips["galleries_quest"]!=null and "vannes" in game.voice.captions["galleries_quest"],"Updated quest voice and subtitles must exist")
	check(room.pumps[0].bus=="Ambiances","Pump hum must respect the ambience slider")
	await settle(game,room.pad_position+Vector3(0,0.04,0))
	room.last_position=game.player.position
	room.update(5)
	check(not room.solved and room.quiet_time==0,"Standing on the sensor cannot bypass running pumps")
	await settle(game,room.origin+Vector3(0,0.05,-13))
	for i in range(90):
		game.player.velocity=Vector3(0,-2,-4.6); game.player.move_and_slide(); await physics_frame
	check(game.player.position.z>game.labyrinth.origin.z and not game.labyrinth.inside(),"Closed door physically blocks the labyrinth")
	await settle(game,room.origin+Vector3(0,0.05,12))
	for local in [Vector3(-3,0,12),Vector3(-3,0,2),Vector3(-7.1,0,2),Vector3(-7.1,0,6),Vector3(-8.6,0,6)]:
		check(await walk_to(game,room.origin+local),"Walkable path to left valve: "+str(local))
	aim_at(game,room.wheels[0].global_position)
	check(room.valve_in_reach()==0,"Left valve must be usable from its front")
	game.paused=true; room.interact(); check(room.closed==[false,false],"No valve interaction while paused"); game.paused=false
	room.interact(); room.update(0.1)
	check(room.closed==[true,false] and not room.solved,"First valve closes without opening the door")
	room.interact(); check(room.closed==[true,false],"Repeated input cannot reopen a valve")
	game.checkpoints.observe()
	var partial: Dictionary=game.checkpoints.latest.duplicate(true)
	check(partial.get("silence_valves")==[true,false] and not partial.get("silence_open"),"Partial completion must be saved to the checkpoint")
	game.checkpoints.apply_save(partial)
	check(room.closed==[true,false] and not room.solved,"Reload restores the partial challenge")
	var inspection=game.get_node("Inspection")
	inspection.jump(3); check(room.solved and room.closed==[true,true],"Labyrinth inspection bypasses the prerequisite safely")
	game.checkpoints.observe(); check(game.checkpoints.latest==partial,"Inspection cannot overwrite the real save")
	inspection.leave(); check(room.closed==[true,false] and not room.solved,"Leaving inspection restores partial valve progress")
	await settle(game,room.origin+Vector3(0,0.05,12))
	for local in [Vector3(3,0,2),Vector3(3,0,-6),Vector3(7.1,0,-6),Vector3(7.1,0,-4),Vector3(8.6,0,-4)]:
		check(await walk_to(game,room.origin+local),"Walkable path to right valve: "+str(local))
	aim_at(game,room.wheels[1].global_position)
	check(room.valve_in_reach()==1,"Right valve must be usable from its front")
	var obstacle:=StaticBody3D.new(); obstacle.position=game.interaction_origin().lerp(room.wheels[1].global_position,0.5)
	var collision:=CollisionShape3D.new(); var shape:=BoxShape3D.new(); shape.size=Vector3(3,3,0.15); collision.shape=shape
	obstacle.add_child(collision); game.add_child(obstacle); await physics_frame
	check(room.valve_in_reach()==-1,"A valve cannot be activated through a wall")
	obstacle.collision_layer=0; await physics_frame
	room.interact(); room.update(1.1)
	check(room.closed==[true,true] and not room.solved,"Both valves are necessary but not sufficient")
	game.audio_mix.update_mix(1)
	check(game.audio_mix.music_duck<=-28 and room.pumps[0].volume_db<=-59.9 and room.pumps[1].volume_db<=-59.9,"The room must audibly fall quiet after both valves close")
	for local in [Vector3(7.1,0,-4),Vector3(7.1,0,-6),Vector3(3,0,-6),Vector3(0,0,-10.6)]:
		check(await walk_to(game,room.origin+local),"Return path to sensor: "+str(local))
	await settle(game,room.pad_position+Vector3(0,0.04,0))
	check(room.on_pad(),"The sensor sits on a walkable floor")
	room.last_position=game.player.position; room.movement_cooldown=0; room.quiet_time=0; room.update(1.5)
	check(is_equal_approx(room.quiet_time,1.5),"Stillness advances the visible three-second countdown")
	game.paused=true; room.update(10)
	check(is_equal_approx(room.quiet_time,1.5) and not room.solved,"Pause cannot finish the countdown")
	game.paused=false; game.editor.active=true; room.update(10)
	check(is_equal_approx(room.quiet_time,1.5) and not room.solved,"Editor cannot finish the countdown")
	game.editor.active=false
	Input.action_press("forward"); room.update(0.1); Input.action_release("forward")
	check(room.quiet_time==0 and room.closed==[true,true],"Movement resets only the countdown")
	room.movement_cooldown=0; room.update(1); Input.action_press("push"); room.update(0.1); Input.action_release("push")
	check(room.quiet_time==0,"Striking interrupts silence")
	room.movement_cooldown=0; room.update(1); Input.action_press("jump"); room.update(0.1); Input.action_release("jump")
	check(room.quiet_time==0,"Jumping interrupts silence")
	room.movement_cooldown=0; room.update(1); game.player.position.x+=1.5; room.update(0.1)
	check(room.quiet_time==0 and not room.solved,"Leaving the circle interrupts silence")
	await settle(game,room.pad_position+Vector3(0,0.04,0))
	room.last_position=game.player.position; room.movement_cooldown=0
	AudioServer.set_bus_mute(0,true)
	game.camera.rotate_y(0.4); room.update(2.9)
	check(not room.solved and room.quiet_time>2.8,"Camera movement is allowed, and three full seconds are required")
	room.update(0.11)
	check(room.solved,"The puzzle remains solvable with audio muted")
	AudioServer.set_bus_mute(0,false)
	room.update(2.3); await physics_frame
	check(is_equal_approx(room.opened,1) and room.gate.position.y>room.origin.y+7,"The gate opens fully after the successful hold")
	game.checkpoints.observe(); var completed: Dictionary=game.checkpoints.latest.duplicate(true)
	check(completed.silence_open and completed.silence_valves==[true,true],"Open door is saved permanently")
	game.checkpoints.apply_save(completed); check(room.solved and room.opened==1,"Reload keeps the door open without replaying the challenge")
	await settle(game,room.origin+Vector3(0,0.05,-13))
	check(await walk_to(game,game.labyrinth.cell_at(Vector2i(4,0))),"Player can physically walk through the open doorway into the labyrinth")
	game.checkpoints.observe()
	check(game.checkpoints.stage==3 and game.labyrinth.inside(),"Entering the maze advances the checkpoint")
	game.checkpoints.apply_save(old_save(3)); check(room.solved and room.opened==1,"Legacy maze saves are not locked backwards")
	var malformed:=old_save(); malformed.silence_valves=[true]; check(not game.checkpoints.valid(malformed),"Malformed valve arrays are rejected")
	malformed=old_save(); malformed.silence_valves=[false,false]; malformed.silence_open=true
	check(not game.checkpoints.valid(malformed),"Impossible open-door saves are rejected")
	game.checkpoints.apply_save(old_save(1)); check(not room.solved and room.closed==[false,false],"Restarting earlier resets the challenge")
	game.queue_free(); await process_frame; await process_frame
	print("SILENCE: %d checks, %d failures" % [checks,failures.size()])
	quit(0 if failures.is_empty() else 1)
