extends SceneTree
func _initialize() -> void:call_deferred("run")
func check(ok: bool, msg: String) -> void:
	if not ok:push_error(msg);quit(1)
func run() -> void:
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame
	game.land_in_chamber();game.puzzle.solved=true
	# This test starts after room 02; its closed-door challenge has a separate test.
	game.silence.restore([true,true],true)
	# Physical traversal only; lethal pursuit is exercised in test_shadow_death.
	game.scares.enabled=false
	var maze=game.labyrinth
	# Traverse the permanent graph: all 81 cells reachable with every shutter shut.
	var reached={Vector2i(4,0):true};var queue=[Vector2i(4,0)]
	while not queue.is_empty():
		var c: Vector2i=queue.pop_front()
		for d in [Vector2i.LEFT,Vector2i.RIGHT,Vector2i.UP,Vector2i.DOWN]:
			var n: Vector2i=c+d
			if maze.links.has(maze.edge(c,n)) and not reached.has(n):reached[n]=true;queue.append(n)
	check(reached.size()==81,"Maze disconnected")
	# Physically walk from room 2 through the new entrance.
	game.player.position=maze.origin+Vector3(0,0.05,2)
	game.player.rotation=Vector3.ZERO
	Input.action_press("forward")
	for i in range(100):await physics_frame
	Input.action_release("forward")
	check(game.player.position.z<maze.origin.z-1,"Entrance blocked")
	check(game.player.position.y>maze.origin.y-0.1,"Missing floor")
	# Test closing protection directly at each moving membrane.
	for shutter in maze.shutters:
		game.player.position=Vector3(shutter.position.x,maze.origin.y+0.05,shutter.position.z)
		shutter.position.y=float(shutter.get_meta("rest_y"))+5.5
		maze.update(1)
		check(shutter.position.y>=float(shutter.get_meta("rest_y"))+5.49,"Unsafe shutter close")
	# Collect all nodes, repeat interaction cannot double count.
	for i in range(3):
		game.player.position=maze.cell_at(maze.organ_cells[i])+Vector3(0,0.05,1)
		await physics_frame
		maze.interact();maze.interact()
		check(maze.collected.count(true)==i+1,"Node activation failed")
	game.player.position=maze.cell_at(Vector2i(4,8))+Vector3(0,0.05,0)
	maze.update(3)
	check(maze.opened==1,"Exit failed to open")
	var before: float=maze.clock
	game.paused=true;maze.update(5)
	check(maze.clock==before,"Pause failed")
	game.paused=false
	Input.action_press("forward")
	for i in range(160):await physics_frame
	Input.action_release("forward")
	check(maze.complete,"Cannot enter resting chamber")
	check(game.player.position.y>maze.origin.y-0.1,"Missing resting floor")
	print("PASS: 81 connected cells, entry collision, safe shutters, 3 nodes, pause, exit and resting floor")
	quit()
