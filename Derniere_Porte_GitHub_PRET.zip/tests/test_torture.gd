extends SceneTree
var failures: Array[String]=[]
func _initialize() -> void:call_deferred("run")
func check(value: bool,message: String) -> void:
	if not value:failures.append(message);printerr("FAIL: "+message)
func blocked(game: Node,from: Vector3,motion: Vector3) -> bool:
	var query:=PhysicsTestMotionParameters3D.new()
	query.from=Transform3D(Basis.IDENTITY,from);query.motion=motion;query.margin=0.01
	return PhysicsServer3D.body_test_motion(game.player.get_rid(),query)
func run() -> void:
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	game.front_end.new_game();game.set_physics_process(false);game.torture.set_physics_process(false)
	game.voice.enabled=false;game.voice.reset_announcements();game.experience.set_process(false)
	game.scares.enabled=false
	var room=game.torture
	var data:={"version":1,"stage":5,"nodes":[true,true,true],"sword":true,"stick":true,"spores":true,"events":{},"simon_done":false}
	check(game.checkpoints.valid(data),"Old stage-five saves must still load")
	game.checkpoints.apply_save(data)
	await physics_frame;await physics_frame
	check(blocked(game,game.simon.origin+Vector3(0,0.06,-22),Vector3(0,0,-4)),"Simon gate must block access before victory")
	game.simon.restore(true)
	await physics_frame;await physics_frame
	check(not blocked(game,game.simon.origin+Vector3(0,0.06,-22),Vector3(0,0,-4)),"Simon gate must clear after victory")
	check(not blocked(game,game.simon.origin+Vector3(0,0.06,-28.5),Vector3(0,0,-4)),"Service corridor must reach the new room")
	data.stage=6;data.simon_done=true;game.checkpoints.apply_save(data)
	await physics_frame;await physics_frame
	check(room.inside(),"Stage six must restore inside the new room")
	check(game.combat.won and game.simon.won,"Earlier doors must stay open")
	room.update(0.01)
	check(room.actor.visible,"Quest actor must exist with random horror disabled")
	check(not room.captured and room.doses==0,"New quest must start with a free mushroom")
	# Follow the actual physics actor: its speed/fatigue must make it catchable.
	room.set_physics_process(true)
	var caught_up:=false
	for frame in range(1200):
		await physics_frame
		var direction: Vector3=room.actor.position-game.player.position;direction.y=0
		if direction.length()<1.8:caught_up=true;break
		game.experience.move_player(1.0/60.0,direction.normalized(),4.6)
	check(caught_up,"A sprinting player must be able to catch the moving actor")
	check(room.actor.position.y>room.origin.y-0.2,"Quest actor must stay above the floor")
	room.set_physics_process(false);room.restore(false,0)
	game.player.position=room.actor.position+Vector3(0,0,1.7)
	game.player.rotation=Vector3.ZERO;game.camera.rotation=Vector3.ZERO
	await physics_frame;await physics_frame
	check(room.can_reach(room.actor.position+Vector3.UP*0.7),"Mushroom should be reachable at capture distance")
	var wall=game.box(room.actor.position+Vector3(0,1,0.8),Vector3(2,2,0.15),Color.WHITE)
	await physics_frame;await physics_frame
	room.interact();check(not room.captured,"Capture must not pass through a wall")
	wall.queue_free();await physics_frame;await physics_frame
	room.interact();check(room.captured,"Interact should capture the mushroom")
	game.paused=true;var remaining: float=room.capture_left;room.update(1)
	check(room.capture_left==remaining,"Pause must freeze capture")
	game.paused=false;room.update(1)
	check(room.actor.position.is_equal_approx(room.seat_position) and room.restraints.visible,"Capture must place mushroom in restraints")
	game.checkpoints.observe()
	var capture_save: Dictionary=game.checkpoints.snapshot()
	check(capture_save.torture_captured and capture_save.torture_doses==0,"Capture must be saved")
	game.player.position=room.console_position+Vector3(0,-1.2,1.9)
	game.player.rotation=Vector3.ZERO;game.camera.rotation=Vector3.ZERO
	await physics_frame;await physics_frame
	room.interact();check(room.doses==1 and not game.inventory.has_spores,"First pulse must consume the item once")
	room.interact();check(room.doses==1,"Repeated input must not skip the discharge animation")
	await physics_frame;await physics_frame
	game.editor.active=true;remaining=room.pulse_left;room.update(5)
	check(room.pulse_left==remaining and room.voice.stream_paused,"Editor must freeze discharge and sound")
	game.editor.active=false;room.update(2)
	game.checkpoints.observe();var mid_save: Dictionary=game.checkpoints.snapshot()
	check(game.checkpoints.valid(mid_save),"Mid-quest snapshot must be valid")
	room.restore(false,0);game.checkpoints.apply_save(mid_save)
	check(room.doses==1 and room.captured and not game.inventory.has_spores,"Reload must keep charge progress without duplicating spores")
	game.player.position=room.console_position+Vector3(0,-1.2,1.9)
	await physics_frame;await physics_frame
	for i in range(2):room.interact();room.update(2)
	room.update(2)
	check(room.completed and room.opened==1,"Three discharges must open the exit")
	await physics_frame;await physics_frame
	check(not blocked(game,room.origin+Vector3(0,0.06,-26),Vector3(0,0,-4)),"Exit collision must move with the gate")
	game.checkpoints.observe();var final_save: Dictionary=game.checkpoints.snapshot()
	game.checkpoints.apply_save(final_save)
	check(room.completed and room.opened==1,"Completion must survive reload")
	# A pre-existing save with no reward remains playable through the culture graft.
	data.spores=false;game.checkpoints.apply_save(data)
	game.player.position=room.specimen_position+Vector3(0,-1.05,1.4)
	game.player.rotation=Vector3.ZERO;game.camera.rotation=Vector3.ZERO
	await physics_frame;await physics_frame
	room.interact();check(game.inventory.has_spores,"Missing spores must be recoverable")
	var inspection=game.get_node("Inspection");var previous: Dictionary=game.checkpoints.latest.duplicate(true)
	inspection.jump(6);room.update(0.01)
	check(room.inside() and room.actor.visible,"F3 inspection must reach a playable quest")
	game.checkpoints.observe();check(game.checkpoints.latest==previous,"Inspection must not overwrite the real save")
	inspection.jump(0);check(not room.captured and room.doses==0,"Room inspection must reset quest state")
	inspection.leave();check(not inspection.active,"Inspection must return to the original run")
	data.torture_doses=4;check(not game.checkpoints.valid(data),"Invalid dose counts must be rejected")
	game.queue_free();await process_frame;await process_frame
	if failures.is_empty():print("PASS: room access, physical gates, capture, spores, pause/editor, old saves, progression and inspection")
	quit(0 if failures.is_empty() else 1)
