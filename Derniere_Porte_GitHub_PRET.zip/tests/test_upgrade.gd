extends SceneTree
var failed := false
func _initialize() -> void:call_deferred("run")
func check(ok: bool,message: String) -> void:
	if not ok:failed=true;push_error(message)
func run() -> void:
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame
	await physics_frame
	game.front_end.new_game()
	game.set_physics_process(false)
	var c=game.combat;var saves=game.checkpoints
	saves.path="user://test_progress.cfg"
	var data={"version":1,"stage":4,"nodes":[true,true,true],"sword":true,"stick":true,"spores":false,"events":{},"simon_done":false,"torture_captured":false,"torture_doses":0}
	saves.apply_save(data)
	check(game.puzzle.solved and c.equipped and game.labyrinth.opened==1,"Restore prerequisites")
	check(c.inside() and c.health==100,"Restore safe spawn")
	game.player.position=c.origin+Vector3(0,0.05,-10)
	var enemy=c.enemies[0];enemy.position=game.player.position+Vector3(0,0,-2)
	await physics_frame
	Input.action_press("push");c.begin_charge();c.update(0.8);Input.action_release("push");c.release_charge()
	check(int(enemy.get_meta("hp"))==1,"Charged attack must deal two damage")
	c.cooldown=0;enemy.set_meta("hp",3)
	Input.action_press("push");c.begin_charge();c.update(0.1);Input.action_release("push");c.release_charge()
	check(int(enemy.get_meta("hp"))==2,"Quick attack must deal one damage")
	c.cooldown=0;Input.action_press("push");c.begin_charge();game.controls.open();Input.action_release("push");game.controls.close()
	check(not c.charging,"Menu cancels charging")
	c.health=100;c.stamina=100;c.cooldown=0
	Input.action_press("parry");c.update(0.01);c.receive_strike(enemy)
	check(c.health==100 and c.stamina==75 and float(enemy.get_meta("rest"))==1.8,"Perfect parry")
	game.player.rotation.y=PI;c.receive_strike(enemy)
	check(c.health==82,"Rear attack bypasses guard")
	Input.action_release("parry");game.player.rotation.y=0
	# Persist partial maze collection and completed prerequisites.
	data.stage=3;data.nodes=[true,false,true];data.sword=false;data.events={"silhouette":true}
	saves.apply_save(data);saves.observe()
	check(FileAccess.file_exists(saves.path),"Save missing")
	game.labyrinth.collected=[false,false,false];game.puzzle.solved=false
	saves.load_progress()
	check(game.puzzle.solved and game.labyrinth.collected==[true,false,true],"Partial puzzle not restored")
	check(game.scares.fired.has("silhouette"),"Event history not restored")
	check(not saves.valid({"version":1,"stage":99}),"Invalid save accepted")
	data.stage=5;data.nodes=[true,true,true];data.sword=true;saves.apply_save(data);saves.fingerprint="";saves.observe();saves.load_progress()
	check(c.won and c.opened==1 and int(c.enemies[0].get_meta("hp"))==0,"Victory not preserved")
	# One-shot apparition, pause freezes it, turning away dismisses it.
	game.scares.restore({});game.scares.enabled=true
	game.player.position=game.puzzle.origin+Vector3(0,0.05,-18)
	game.scares.update(0.1);check(game.scares.silhouette.visible,"Apparition trigger")
	var remaining: float=game.scares.apparition_time;game.paused=true;game.scares.update(3)
	check(game.scares.apparition_time==remaining,"Horror pause")
	game.paused=false;game.player.rotation.y=PI;game.scares.update(3)
	check(not game.scares.silhouette.visible,"Apparition did not disappear")
	game.scares.update(0.1);check(not game.scares.silhouette.visible,"Repeated apparition")
	game.controls.open();await process_frame;await process_frame
	var panel=game.controls.layer.get_child(1)
	print("MENU SIZE ",panel.size)
	for child in panel.get_children():print(child.get_class()," ",child.size)
	check(panel.position.y+panel.size.y<=720,"Pause menu exceeds viewport")
	game.controls.close()
	DirAccess.remove_absolute(ProjectSettings.globalize_path(saves.path))
	if not failed:print("PASS: charged/light attacks, front parry, back damage, pause cancellation, checkpoint save/load, partial nodes, victory, validation, horror triggers and menu layout")
	quit(1 if failed else 0)
