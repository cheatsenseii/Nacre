extends SceneTree
var failures: Array[String] = []
var checks := 0

func _initialize() -> void: call_deferred("run")

func check(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures.append(message)
		printerr("FAIL: " + message)

func save_for_room() -> Dictionary:
	return {"version":1,"stage":7,"nodes":[true,true,true],"sword":true,"stick":true,"spores":false,"events":{},"simon_done":true,"torture_captured":true,"torture_doses":3,"horror_started":false,"horror_revealed":false,"horror_completed":false}

func run() -> void:
	var game = load("res://main.tscn").instantiate()
	root.add_child(game)
	await physics_frame
	await physics_frame
	game.front_end.launch()
	game.set_physics_process(false)
	game.voice.enabled = false
	game.checkpoints.apply_save(save_for_room())
	game.get_node("Inspection").active = true
	var room = game.horrors
	room.unlocked = false
	game.torch.show()
	game.torch.light_energy = 3.5
	room.update(0.01)
	check(room.unlocked and room.started and room.phase == "blackout", "Torture completion unlocks the room on natural entry")
	check(room.dark_overlay.color.a == 1 and room.torch_locked and not game.torch.visible, "Complete blackout and broken torch")
	check(room.bodies.size() >= 12 and not room.bodies[0].visible, "Bodies concealed until the first flash")
	room.notify_torch()
	check(not game.torch.visible and room.torch_locked, "The torch button cannot bypass the blackout")
	room.update(4.98)
	check(room.phase == "blackout" and not room.revealed, "No premature reveal before five seconds")
	var remaining: float = room.timer
	game.paused = true
	room.update(3)
	check(is_equal_approx(room.timer, remaining) and room.dark_overlay.color.a == 0, "Pause freezes timing and makes menus readable")
	game.paused = false
	game.editor.active = true
	room._process(1)
	check(not room.torch_locked and room.dark_overlay.color.a == 0 and room.bodies[0].visible, "Editor clears the blackout and shows the scene")
	game.editor.active = false
	room.update(0.02)
	check(room.phase == "flicker" and room.revealed and room.shadow.visible, "First flash reveals bodies and shadow at five seconds")
	check(room.shadow_layer.visible and room.shadow_view.render_target_update_mode==SubViewport.UPDATE_ALWAYS,"The scare renders as an isolated lit 3D model")
	check(room.shadow_eyes[0].global_position.distance_to(game.camera.global_position) < 4, "Apparition appears directly in front of the camera")
	check(room.fear_weight > 0.9 and room.bodies[0].visible, "Character reacts and bodies are readable")
	var polish = game.get_node("Realism").polish
	polish.update_light_budget()
	check(room.lamps[0].visible, "General light culling cannot extinguish scripted flashes")
	room.update(0.48)
	check(room.shadow.visible, "The apparition remains for the full half-second")
	room.update(0.02)
	check(not room.shadow.visible, "The apparition disappears at half a second")
	check(not room.shadow_layer.visible and room.shadow_view.render_target_update_mode==SubViewport.UPDATE_DISABLED,"The extra 3D render stops immediately after the apparition")
	game.player.position = game.torture.origin + Vector3(0,0.05,-27)
	room.update(1)
	check(room.dark_overlay.color.a == 0 and not room.torch_locked and not room.shadow.visible, "Leaving mid-sequence clears every screen effect")
	game.player.position = room.origin + Vector3(0,0.05,-2)
	room.update(0.01)
	check(room.torch_locked and not room.shadow.visible, "Re-entry resumes without repeating the apparition")
	game.torture.lighting_settings.stable_lighting = true
	room.update(0.2)
	check(room.lamps[0].visible and room.flash_overlay.color.a == 0, "Stable-light setting avoids repeated flashes")
	room.update(4)
	check(room.phase == "explore" and not room.torch_locked and game.torch.visible, "Exploration restores the player's original torch state")
	check(is_equal_approx(game.torch.light_energy,3.5), "Original torch power restored")
	check(not game.inventory.has_spores, "Consumed spores remain consumed")
	game.feeding.update(1)
	check(not game.inventory.has_spores and not game.feeding.cry.playing, "Loading after torture cannot replay the mushroom reward")
	var save := save_for_room()
	save.horror_started = true
	save.horror_revealed = true
	check(game.checkpoints.valid(save), "A revealed-room save validates")
	save.horror_started = false
	check(not game.checkpoints.valid(save), "Impossible reveal-before-entry save is rejected")
	save.horror_started = true
	game.checkpoints.apply_save(save)
	room.update(0.1)
	check(room.phase == "explore" and room.shadow_time == 0 and not room.torch_locked, "Loading a completed reveal does not replay the scare")
	game.player.position = room.origin + Vector3(0,0.05,-28)
	room.update(2)
	check(room.completed and room.gate.position.y > room.origin.y+6, "Exit gate opens on approach")
	await physics_frame
	var space = game.get_world_3d().direct_space_state
	for z in [1.0,-0.1,-15.0,-29.8,-30.2,-32.0,-35.0]:
		var at: Vector3 = room.origin + Vector3(0,1,z)
		var ray = PhysicsRayQueryParameters3D.create(at,at-Vector3.UP*2,1,[game.player.get_rid()])
		var hit: Dictionary = space.intersect_ray(ray)
		check(not hit.is_empty() and hit.normal.y>0.9, "Continuous floor at room z=%.1f" % z)
	game.player.position = room.origin + Vector3(0,0.05,-33.5)
	room.update(0.1)
	check(game.finished and room.inside(), "The ending is reachable inside the supported exit passage")
	game.finished = false
	room.restore(false,false,false)
	check(room.dark_overlay.color.a == 0 and room.flash_overlay.color.a == 0 and not room.shadow.visible, "Reset clears all presentation state")
	var inspection = game.get_node("Inspection")
	inspection.active = false
	var original_save := {"version":1,"stage":0,"nodes":[false,false,false],"sword":false,"events":{}}
	game.checkpoints.apply_save(original_save)
	var latest: Dictionary = game.checkpoints.latest.duplicate(true)
	inspection.jump(7)
	room.update(0.1)
	game.checkpoints.observe()
	check(game.checkpoints.latest == latest, "Inspection never overwrites the real checkpoint")
	inspection.jump(0)
	check(not room.torch_locked and room.dark_overlay.color.a == 0 and not room.started, "Inspection room jump cleans up a running blackout")
	inspection.leave()
	check(not game.arrived and game.checkpoints.stage == 0, "Leaving inspection restores the original progression")
	game.queue_free()
	await process_frame
	await process_frame
	print("HORREURS: %d checks, %d failures" % [checks, failures.size()])
	quit(0 if failures.is_empty() else 1)
