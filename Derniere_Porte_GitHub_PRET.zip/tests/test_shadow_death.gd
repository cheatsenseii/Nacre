extends SceneTree
var failures: Array[String]=[]
var checks:=0
var game: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, message: String) -> void:
	checks+=1
	if not ok: failures.append(message); printerr("FAIL: "+message)
func freeze_scripts(node: Node) -> void:
	node.set_process(false); node.set_physics_process(false)
	for child in node.get_children(): freeze_scripts(child)
func maze_save() -> Dictionary:
	return {"version":1,"stage":3,"nodes":[true,false,false],"sword":false,"stick":true,"spores":true,"events":{}}
func arm(at: Vector3) -> void:
	var scare=game.scares
	scare.enabled=true; scare.shadow_safe_time=0; scare.shadow_age=2; scare.shadow_time=18
	scare.maze_shadow.global_position=at; scare.maze_shadow.show()
func run() -> void:
	game=load("res://main.tscn").instantiate(); root.add_child(game)
	await physics_frame; await physics_frame
	game.front_end.launch(); freeze_scripts(game); game.voice.enabled=false
	game.checkpoints.apply_save(maze_save())
	await physics_frame
	var scare=game.scares; var nav=scare.shadow_nav; var maze=game.labyrinth; var death=game.death
	# Full physical graph, including routes around all three solid pedestals.
	nav.prepare_graph()
	check(nav.graph.get_point_count()>=81,"Navigation covers every cell, with detours around solid pedestals")
	var destinations:=0
	for y in range(9):
		for x in range(9):
			var ids: Array=nav.anchors.get(Vector2i(x,y),[])
			if not ids.is_empty() and not nav.graph.get_point_path(0,ids[0]).is_empty(): destinations+=1
	check(destinations==81,"All 81 cells are reachable without crossing any closed membrane")
	var pedestal_center: Vector3=nav.center(maze.organ_cells[2])
	check(not nav.free_at(pedestal_center),"The navigation capsule detects the node pedestal")
	var around: PackedVector3Array=nav.build_route(pedestal_center+Vector3(-1,0,0),pedestal_center+Vector3(1,0,0))
	check(around.size()>=3,"Route goes around a pedestal instead of sticking to its center")
	var position: Vector3=pedestal_center+Vector3(-1,0,0)
	var target: Vector3=pedestal_center+Vector3(1,0,0)
	var free_steps:=true
	for i in range(180):
		var next: Vector3=nav.step(position,target,2.25,1.0/30)
		free_steps=free_steps and nav.safe_fraction(position,next)>0.99; position=next
		if position.distance_to(target)<0.1: break
	check(free_steps and position.distance_to(target)<0.1,"Actual pursuit steps go around the pedestal without clipping it")
	# A non-linked neighboring cell requires taking a real corridor around a wall.
	var from:=Vector3.ZERO; var to:=Vector3.ZERO
	var best:=INF
	for y in range(9):
		for x in range(8):
			var a:=Vector2i(x,y); var b:=a+Vector2i.RIGHT
			if maze.links.has(maze.edge(a,b)): continue
			var first: Vector3=nav.center(a); var last: Vector3=nav.center(b)
			if not nav.free_at(first) or not nav.free_at(last): continue
			var route: PackedVector3Array=nav.build_route(first,last)
			if route.size()>2 and route.size()<best: best=route.size(); from=first; to=last
	check(from!=Vector3.ZERO and nav.safe_fraction(from,to)<0.999,"Test route crosses a real closed wall if taken directly")
	nav.route.clear(); position=from; free_steps=true
	for i in range(2400):
		var next: Vector3=nav.step(position,to,2.25,1.0/30)
		free_steps=free_steps and nav.safe_fraction(position,next)>0.99; position=next
		if position.distance_to(to)<0.15: break
	check(free_steps and position.distance_to(to)<0.15,"Actual pursuit reaches the other side through corridors, never through the wall")
	# Direct contact has line of sight, vertical and pause guards.
	game.player.position=(from+to)/2+Vector3(0.38,0,0)
	arm((from+to)/2-Vector3(0.38,0,0))
	check(not scare.shadow_can_catch(),"A thin wall blocks capture even when the two bodies are close")
	game.player.position=nav.center(Vector2i(4,0)); arm(game.player.position+Vector3(0,0,-0.6))
	check(scare.shadow_can_catch(),"An unprotected player in actual contact can be caught")
	scare.shadow_age=0.5; check(not scare.shadow_can_catch(),"The first 1.4 seconds of an apparition cannot kill")
	scare.shadow_age=2; scare.shadow_safe_time=1; check(not scare.shadow_can_catch(),"Respawn protection prevents capture")
	scare.shadow_safe_time=0; scare.maze_shadow.hide(); check(not scare.shadow_can_catch(),"An invisible shadow cannot capture")
	scare.maze_shadow.show(); scare.enabled=false; check(not scare.shadow_can_catch(),"Disabling horror events disables shadow damage")
	scare.enabled=true; game.paused=true; check(not scare.shadow_can_catch(),"Pause blocks capture")
	game.paused=false; game.editor.active=true; check(not scare.shadow_can_catch(),"Editor blocks capture")
	game.editor.active=false; game.front_end.active=true; check(not scare.shadow_can_catch(),"Main menu blocks capture")
	game.front_end.active=false; game.player.position.y+=2; check(not scare.shadow_can_catch(),"No capture on a different vertical level")
	game.player.position=maze.origin+Vector3(0,0.05,-39); arm(game.player.position+Vector3(0,0,-0.6))
	check(not scare.shadow_can_catch(),"Resting chamber after the maze is safe")
	game.player.position=game.simon.origin+Vector3(0,0.05,-3); arm(game.player.position+Vector3(0,0,-0.6))
	check(not scare.shadow_can_catch(),"Maze capture cannot happen in Simon or another room")
	game.checkpoints.apply_save(maze_save()); scare.shadow_safe_time=0
	check(not scare.start_shadow(game.player.position+Vector3(0,0,-1),1),"Spawn cannot appear in contact range")
	# Pick an actual open edge near the entrance, then let the shadow reach the player.
	var start: Vector3=nav.center(Vector2i(4,0))
	var spawn:=Vector3.ZERO
	for direction in [Vector2i.LEFT,Vector2i.RIGHT,Vector2i.DOWN]:
		var cell: Vector2i=Vector2i(4,0)+direction
		if maze.links.has(maze.edge(Vector2i(4,0),cell)) and nav.free_at(nav.center(cell)): spawn=nav.center(cell); break
	game.player.position=start
	check(scare.start_shadow(spawn,1),"Shadow can spawn at least four metres away in a real corridor")
	var at: Vector3=scare.maze_shadow.position
	scare.update_maze_shadow(0.5,true)
	check(scare.maze_shadow.position==at and scare.shadow_age==0,"Frozen update does not advance pursuit or warmup")
	scare.update_maze_shadow(0.5,false)
	check(scare.maze_shadow.position==at and not death.active,"Warmup holds the shadow before movement starts")
	maze.collected[1]=true
	scare.escalate_maze_shadow(2)
	check(scare.maze_shadow.position==at,"Activating a node accelerates a live shadow without teleporting it")
	check(scare.SHADOW_SPEEDS[0]<scare.SHADOW_SPEEDS[1] and scare.SHADOW_SPEEDS[1]<scare.SHADOW_SPEEDS[2] and scare.SHADOW_SPEEDS[2]<scare.SHADOW_SPEEDS[3] and scare.SHADOW_SPEEDS[3]<4.6,"Pressure rises with all three nodes while sprint remains faster")
	for i in range(400):
		scare.update_maze_shadow(1.0/60,false)
		if death.active: break
	check(death.active and game.health==0,"Actual frame-by-frame pursuit kills the stationary player")
	check(game.paused and game.player.velocity==Vector3.ZERO and death.layer.visible,"Death freezes the player and presents its overlay")
	check(not death.begin(),"A capture cannot trigger twice")
	check(death.resume_data.nodes==[true,true,false],"A node activated just before capture is kept in the checkpoint")
	check(death.sound.bus=="Apparitions","Death cue uses the scare bus and respects the night mix")
	game.audio_mix._process(0.1)
	check(not death.sound.stream_paused,"Death cue remains audible while the world is frozen")
	var click:=InputEventMouseButton.new(); click.pressed=true; click.button_index=MOUSE_BUTTON_LEFT
	game._unhandled_input(click); game._physics_process(0.1)
	check(death.active and game.paused and game.player.position==start,"Clicking during death cannot unpause or move the character")
	death.update(1)
	check(death.active and game.third_person.avatar.rotation.z<0,"Death animation runs before checkpoint return")
	game.controls.open(); var elapsed: float=death.elapsed; death.update(5); game.audio_mix._process(0.1)
	check(death.elapsed==elapsed and not death.layer.visible and death.sound.stream_paused,"Opening settings suspends death, hides the overlay and pauses its sound")
	game.controls.close(); death.update(0.1)
	check(death.active and death.layer.visible and game.paused,"Closing settings resumes the sequence without restoring movement early")
	game.editor.active=true; elapsed=death.elapsed; death.update(5)
	check(death.elapsed==elapsed,"Editor also suspends the death timer")
	game.editor.active=false; death.update(2)
	check(not death.active and game.health==100 and not game.paused,"Respawn restores life and normal play")
	check(game.player.position.distance_to(nav.center(Vector2i(4,0)))<0.1 and maze.collected==[true,true,false],"Respawn returns to the maze entrance with both nodes preserved")
	check(not death.layer.visible and game.third_person.avatar.rotation==Vector3.ZERO,"Death overlay and collapsed pose are cleared on respawn")
	check(scare.shadow_safe_time==6 and not scare.maze_shadow.visible,"Respawn grants six seconds before the next apparition")
	scare.update_maze_shadow(5,false)
	check(not scare.maze_shadow.visible and not death.active and scare.shadow_safe_time>0,"The respawn grace period is actually enforced")
	# A closing living shortcut must not intersect the active pursuer.
	var shutter: MeshInstance3D=maze.shutters[0]
	arm(Vector3(shutter.position.x,maze.origin.y+0.05,shutter.position.z)); game.player.position=nav.center(Vector2i(4,0))
	shutter.position.y=float(shutter.get_meta("rest_y"))+5.5; maze.clock=10; maze.update(0.1)
	check(shutter.position.y>=float(shutter.get_meta("rest_y"))+5.49,"A closing membrane leaves space for the pursuing shadow")
	# Inspection deaths must not overwrite the real save or kick us into real play.
	var real_save: Dictionary=game.checkpoints.latest.duplicate(true)
	var inspection=game.get_node("Inspection"); inspection.jump(3); maze.collected[2]=true
	arm(game.player.position+Vector3(0,0,-0.6)); scare.update_maze_shadow(0.01,false)
	check(death.active and death.resume_data.nodes==[false,false,true],"Inspection death uses the inspected room state")
	death.update(3); game.checkpoints.observe()
	check(inspection.active and inspection.index==3 and game.checkpoints.latest==real_save,"Inspection respawn stays in inspection and preserves the real save")
	arm(game.player.position+Vector3(0,0,-0.6)); scare.update_maze_shadow(0.01,false)
	inspection.jump(4)
	check(not death.active and not death.layer.visible and game.combat.inside(),"Skipping rooms during death cancels the sequence cleanly")
	inspection.leave()
	check(game.checkpoints.latest==real_save and maze.collected==[true,true,false],"Returning from inspection restores real node progression")
	arm(game.player.position+Vector3(0,0,-0.6)); scare.update_maze_shadow(0.01,false)
	game.checkpoints.apply_save({"version":1,"stage":0,"nodes":[false,false,false],"sword":false,"events":{}})
	check(not death.active and not game.paused and not death.layer.visible and not game.arrived,"Restarting at the entrance clears death and pursuit state")
	game.queue_free(); await process_frame; await process_frame
	print("SHADOW DEATH: %d checks, %d failures" % [checks,failures.size()])
	quit(0 if failures.is_empty() else 1)
