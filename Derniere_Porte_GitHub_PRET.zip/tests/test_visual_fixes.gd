extends SceneTree
var game: Node
var checks:=0
var failures: Array[String]=[]
func _initialize():call_deferred("run")
func check(ok: bool,message: String):
	checks+=1
	if not ok:failures.append(message);printerr("FAIL: "+message)
func freeze(node: Node):
	node.set_process(false);node.set_physics_process(false)
	for child in node.get_children():freeze(child)
func run():
	game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	game.front_end.launch();freeze(game);game.voice.enabled=false;game.voice.stop_all()
	var polish=game.get_node("Realism").polish
	game.checkpoints.apply_save({"version":1,"stage":3,"nodes":[false,false,false],"sword":false,"events":{}})
	game.player.position=game.labyrinth.cell_at(Vector2i(1,1))+Vector3.UP*0.05
	for level in range(4):
		polish.quality=level;polish.apply_settings()
		var active:=0;var shadowed:=0
		for light in get_nodes_in_group("nacre_dynamic_light"):
			if light==game.torch or light==game.ceiling_light or light.has_meta("horror_light"):continue
			if light.visible:active+=1
		for light in polish.spots:
			if light.shadow_enabled:shadowed+=1
		check(active<=polish.LIGHT_LIMITS[level],"Hard light budget respected at quality "+str(level))
		check(shadowed<=level and (level==0 or shadowed>0),"Nearby maze practicals receive the shadow budget "+str(level))
		check(not game.atmosphere.glow.visible,"Distant mushroom cannot consume a maze light slot "+str(level))
	var selected: Array=polish.selected_lights.duplicate()
	game.player.position.x+=0.002;polish.update_light_budget()
	check(polish.selected_lights==selected,"Tiny position changes do not shuffle equal-distance lamps")
	# Real movement drives the rig; blocked pursuit must not keep walking in place.
	var actor=game.scares.maze_shadow
	var first: float=actor.legs[0].rotation.x
	actor.animate(0.2,2.0)
	check(absf(actor.legs[0].rotation.x-first)>0.01,"Pursuit animates the legs")
	actor.animate(1.0,0.0)
	check(is_zero_approx(actor.legs[0].rotation.x),"Stopped movement returns to an idle stance")
	actor.set_pressure(3)
	check(actor.eyes[0].material_override.emission_energy_multiplier>1,"Nodes intensify the gaze")
	check(actor.triangle_count<75000,"Detailed rig keeps a bounded geometry cost")
	check(game.scares.silhouette.get_script()==actor.get_script() and game.horrors.shadow.get_script()==actor.get_script(),"All shadow appearances share the reference model")
	var wall_skin: MeshInstance3D=game.labyrinth.shutters[0]
	check(wall_skin.cast_shadow==GeometryInstance3D.SHADOW_CASTING_SETTING_OFF and wall_skin.get_node("Volume_ombre").cast_shadow==GeometryInstance3D.SHADOW_CASTING_SETTING_SHADOWS_ONLY,"Moving membranes have simple inset shadow casters")
	check(not game.get_node("Realism").art.screen.visible,"No second vignette darkens the image")
	# The final shake offset, after the camera boom cast, cannot enter a wall.
	game.checkpoints.apply_save({"version":1,"stage":1,"nodes":[false,false,false],"sword":false,"events":{}})
	game.player.position=game.puzzle.origin+Vector3(7,0.05,4);game.player.rotation=Vector3.ZERO;game.camera.rotation=Vector3.ZERO
	await physics_frame;game.third_person.update_camera(1.0)
	var camera_at: Vector3=game.camera.global_position
	var wall:=StaticBody3D.new();root.add_child(wall)
	var shape:=CollisionShape3D.new();var box:=BoxShape3D.new();box.size=Vector3(0.04,5,8);shape.shape=box;wall.add_child(shape)
	wall.position=camera_at+Vector3(0.28,0,0)
	await physics_frame
	var clear:=true
	for i in range(30):
		game.third_person.shake(0.48,0.9);game.third_person.update_camera(0.02)
		var query:=PhysicsShapeQueryParameters3D.new();query.shape=SphereShape3D.new();query.shape.radius=0.195
		query.transform=Transform3D(Basis.IDENTITY,game.camera.global_position);query.collision_mask=1;query.exclude=[game.player.get_rid()]
		if not game.get_world_3d().direct_space_state.intersect_shape(query,1).is_empty():clear=false
	check(clear,"Thirty strong shakes beside a wall never clip the camera")
	wall.queue_free();await physics_frame
	# A failed write may delay disk IO, never the progression used for respawn.
	var saves=game.checkpoints
	saves.retry_time=5;game.puzzle.solved=true;saves.observe()
	check(saves.stage==2 and saves.latest.stage==2,"Save retry still updates in-memory completion")
	game.health=0;game._physics_process(0.01);game.death.update(3)
	check(game.puzzle.solved and game.health==100,"Death during a save retry preserves the completed challenge")
	# Recover from an accidental fall after changing a level in the editor.
	game.player.position.y=game.puzzle.origin.y-15
	game._physics_process(0.01)
	check(game.death.active,"Falling out of a room starts a recoverable death")
	game.death.update(3)
	check(game.player.position.y>game.puzzle.origin.y-0.1 and game.health==100,"Out-of-bounds fall returns to the doorway")
	check(game.front_end.menu_camera.physics_interpolation_mode==Node.PHYSICS_INTERPOLATION_MODE_OFF,"Render-driven menu camera avoids interpolation warnings")
	game.queue_free();await process_frame;await process_frame
	print("VISUAL FIXES: %d checks, %d failures" % [checks,failures.size()])
	quit(0 if failures.is_empty() else 1)
