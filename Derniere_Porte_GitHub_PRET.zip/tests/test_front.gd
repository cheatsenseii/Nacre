extends SceneTree
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	var front=game.front_end
	assert(front.active and game.paused and front.continue_button.disabled)
	var pos: Vector3=game.player.position;Input.action_press("forward")
	for i in range(10):await physics_frame
	Input.action_release("forward");assert(game.player.position==pos)
	game.controls.open();await process_frame;await process_frame
	assert(not front.layer.visible and game.paused)
	game.controls.close();await process_frame;await process_frame
	assert(front.layer.visible and game.paused)
	front.new_game();await physics_frame
	assert(not front.active and not game.paused and game.health==100)
	game.feeding.health=72;front._process(0.1)
	assert(front.health_bar.value==72 and game.combat.health==72 and front.trail.value>72)
	game.combat.health=18;front._process(1)
	assert(game.feeding.health==18 and front.bar_style.bg_color==Color("e0695b"))
	game.editor.active=true;front._process(0);assert(not front.health_layer.visible);game.editor.active=false
	game.checkpoints.apply_save({"version":1,"stage":2,"nodes":[false,false,false],"sword":false,"events":{}})
	game.checkpoints.observe();game.queue_free();await process_frame
	game=load("res://main.tscn").instantiate();root.add_child(game)
	await physics_frame;await physics_frame
	front=game.front_end
	assert(front.active and not front.continue_button.disabled and not game.arrived)
	front.new_game();assert(front.active and front.confirming)
	front.continue_game();await physics_frame
	assert(not front.active and game.arrived and game.puzzle.solved and game.health==100)
	print("PASS: paused title screen, settings return, new game, shared health display, low health colour, saved Continue and overwrite confirmation")
	quit()
