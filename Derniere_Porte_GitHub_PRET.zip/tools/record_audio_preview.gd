extends SceneTree
## Deterministic demonstration rendered by the game's own audio buses.
func _initialize() -> void: call_deferred("run")
func freeze_scripts(node: Node) -> void:
	node.set_process(false); node.set_physics_process(false)
	for child in node.get_children(): freeze_scripts(child)
func run() -> void:
	var game=load("res://main.tscn").instantiate(); root.add_child(game)
	await physics_frame
	await physics_frame
	game.front_end.new_game(); freeze_scripts(game)
	var mix=game.audio_mix
	mix._process(0.01); mix.set_process(true)
	for player in mix.routed:
		if player!=game.atmosphere.music: player.stop()
	game.voice.enabled=false; mix.ambient_wait=1000
	mix.rng.seed=1998
	game.camera.global_position=game.player.position+Vector3(0,1.7,1.8)
	game.camera.look_at(game.player.position+Vector3(0,1.4,-3))
	var f=game.get_node("Foley"); f.rng.seed=1998
	var recorder:=AudioEffectRecord.new()
	recorder.format=AudioStreamWAV.FORMAT_16_BITS
	AudioServer.add_bus_effect(0,recorder)
	recorder.set_recording_active(true)
	await create_timer(1).timeout
	for surface in ["dalle","eau","organique"]:
		for i in range(4): f.play_step(surface,2.4); await create_timer(0.52).timeout
		await create_timer(0.35).timeout
	var at: Vector3=game.camera.global_position-game.camera.global_basis.z*2
	for cue in ["warning","hit","parry","hurt","death"]:
		mix.play_at(cue,at); await create_timer(0.75).timeout
	await create_timer(0.4).timeout
	game.simon.speaker.global_position=at
	for note in game.simon.tones:
		game.simon.speaker.stream=note; game.simon.speaker.play(); await create_timer(0.5).timeout
	await create_timer(1.1).timeout
	recorder.set_recording_active(false)
	var recording:=recorder.get_recording()
	var args:=OS.get_cmdline_user_args()
	var target: String=args[0] if args.size()>0 else "user://NACRE_apercu_audio.wav"
	var result:=recording.save_to_wav(target)
	print("Audio preview saved: ",target,"; bytes=",recording.data.size(),"; error=",result)
	AudioServer.remove_bus_effect(0,AudioServer.get_bus_effect_count(0)-1)
	game.queue_free(); await process_frame; quit(result)
