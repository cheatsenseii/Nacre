"""Original NACRE sound design. No recordings or downloaded sample packs.

Development only: Python/numpy/scipy/ffmpeg. The game plays baked WAV/OGG files
offline and does not require any of these tools. Seeded for reproducible builds.
"""
from pathlib import Path
import json
import subprocess
import tempfile
import wave
import numpy as np
from scipy import signal

OUT = Path(__file__).parent
RATE = 44100
rng = np.random.default_rng(19980920)
report = {}

def band(x, low, high):
    return signal.sosfilt(signal.butter(2, [low, high], fs=RATE, btype='bandpass', output='sos'), x)

def env(t, attack=.003, decay=.08):
    return (1-np.exp(-np.maximum(t,0)/attack))*np.exp(-np.maximum(t,0)/decay)*(t>=0)

def noise(t, low=180, high=7000):
    x = band(rng.normal(0, 1, len(t)), low, high)
    return x / max(np.std(x), 1e-6)

def finish(x, peak_db=-8, fade=True):
    x = np.asarray(x, dtype=float)
    x -= np.mean(x, axis=0)
    sos = signal.butter(2, 35, fs=RATE, btype='highpass', output='sos')
    x = signal.sosfilt(sos, x, axis=0) if fade else signal.sosfilt(sos, np.concatenate([x,x]), axis=0)[len(x):]
    if fade:
        for length, start in [(int(RATE*.002), True), (int(RATE*.035), False)]:
            ramp = np.linspace(0,1,length) if start else np.linspace(1,0,length)
            if x.ndim == 2: ramp = ramp[:,None]
            if start: x[:length] *= ramp
            else: x[-length:] *= ramp
    x *= 10**(peak_db/20) / max(np.max(np.abs(x)), 1e-6)
    return x

def write(name, x, peak_db=-8, loop=False):
    x = finish(x, peak_db, fade=not loop)
    path = OUT/name
    path.parent.mkdir(parents=True, exist_ok=True)
    report[name] = {'seconds':round(len(x)/RATE,3),'sample_rate':RATE,'peak_db':round(float(20*np.log10(np.max(np.abs(x)))),2),'rms_db':round(float(20*np.log10(np.sqrt(np.mean(x*x)))),2)}
    def wav(target):
        with wave.open(str(target),'wb') as w:
            w.setnchannels(1 if x.ndim==1 else x.shape[1]);w.setsampwidth(2);w.setframerate(RATE)
            w.writeframes(np.rint(x*32767).astype('<i2').tobytes())
    if path.suffix=='.ogg':
        with tempfile.TemporaryDirectory() as folder:
            tmp=Path(folder)/'source.wav';wav(tmp)
            subprocess.run(['ffmpeg','-v','error','-i',str(tmp),'-c:a','libvorbis','-q:a','5','-y',str(path)],check=True)
    else: wav(path)
    return x

def foot(surface, variant):
    t=np.arange(int(RATE*.42))/RATE
    contact=.042+rng.uniform(0,.036)
    # Two noisy contacts (heel then forefoot), with only a little sole resonance.
    heel=noise(t,160,1600)*env(t,.0015,.018)*.30
    heel+=noise(t,1600,6300)*env(t,.001,.006)*.17
    sole=noise(t,85,380)*env(t,.003,.035)*.22
    toe=noise(t,400,4100)*env(t-contact,.002,.020)*.17
    rub=noise(t,800,6500)*env(t-contact-.018,.014,.035)*.055
    x=heel+sole+toe+rub
    if surface=='eau':
        for j in range(5):
            at=.015+j*.018+rng.uniform(0,.009)
            x+=noise(t,1000,7600)*env(t-at,.002,.016)*rng.uniform(.04,.08)
        x+=noise(t,260,1600)*env(t-.07,.014,.05)*.14
    elif surface=='organique':
        x=sole*.85+heel*.28
        pressure=np.sin(2*np.pi*(26+variant*1.3)*t)*.27+.73
        x+=noise(t,120,1500)*env(t,.007,.075)*pressure*.28
        x+=noise(t,650,3000)*env(t-.085,.018,.045)*.15
    # The very short early reflection is kept quiet; room reverb runs in Godot.
    shift=int(RATE*.024)
    x[shift:]+=x[:-shift]*.085
    return x

for surface in ['dalle','eau','organique']:
    for i in range(6):
        write(f'steps/{surface}_{i+1:02d}.wav',foot(surface,i),-8.5+rng.uniform(-.7,.3))

t=np.arange(int(RATE*.4))/RATE
write('saut_tissu.wav',noise(t,700,6500)*np.exp(-((t-.10)/.065)**2)*.11,-14)
t=np.arange(int(RATE*.56))/RATE
land=noise(t,70,350)*env(t,.003,.07)*.35+noise(t,200,2600)*env(t,.002,.026)*.28
land+=noise(t,700,5900)*env(t-.055,.012,.07)*.12
write('reception.wav',land,-7)

t=np.arange(int(RATE*.4))/RATE
swish=noise(t,650,10000)*np.exp(-((t-.095)/.036)**2)
swish+=noise(t,160,850)*np.exp(-((t-.12)/.06)**2)*.22
write('epee.wav',swish,-10)
write('baton_souffle.wav',noise(t,180,3800)*np.exp(-((t-.12)/.05)**2),-12)

for i in range(3):
    t=np.arange(int(RATE*.53))/RATE
    hit=noise(t,95,650)*env(t,.002,.058)*.52
    hit+=noise(t,750,4000)*env(t,.0015,.016)*.34
    hit+=noise(t,250,2300)*env(t-.055,.008,.055)*.14
    write(f'impact_chair_{i+1}.wav',hit,-6.5-i*.3)

def metal(duration, muted=False):
    t=np.arange(int(RATE*duration))/RATE
    x=noise(t,1700,9500)*env(t,.001,.01)*.16
    for hz,weight in [(219,.17),(531,.10),(937,.06),(1441,.05),(2317,.025)]:
        x+=np.sin(2*np.pi*hz*t+rng.uniform(-.1,.1))*env(t,.001,(.045 if muted else .30)*(900/hz)**.3)*weight
    return x

write('parade.wav',metal(.9),-8)
write('garde.wav',metal(.28,True),-9)
write('choc_metal.wav',metal(1.8),-10)
t=np.arange(int(RATE*.7))/RATE
write('joueur_blesse.wav',noise(t,140,900)*env(t,.002,.055)+noise(t,600,4300)*np.exp(-((t-.15)/.085)**2)*.14,-9)
for i in range(3):
    t=np.arange(int(RATE*.52))/RATE
    rasp=noise(t,95,950)*(.65+.35*np.sin(2*np.pi*(37+i*4)*t))
    rasp+=noise(t,900,2400)*.12
    write(f'creature_alerte_{i+1}.wav',rasp*np.sin(np.pi*t/.52)**1.3,-13)

t=np.arange(int(RATE*.95))/RATE
collapse=noise(t,90,750)*env(t,.006,.13)*.7+noise(t,200,2000)*env(t-.17,.02,.10)*.17
write('creature_chute.wav',collapse,-10)

for i in range(3):
    t=np.arange(int(RATE*.9))/RATE
    f=1150+i*230
    drop=np.sin(2*np.pi*(f*t+180*t*t))*env(t,.001,.032)
    drop+=noise(t,1900,6800)*env(t,.001,.009)*.15
    delay=int(RATE*.13)
    drop[delay:]+=drop[:-delay]*.18
    write(f'goutte_{i+1}.wav',drop,-13)

# Distinct, soft-attack notes: the four pitches are stable gameplay information.
for i,hz in enumerate([220,277.18,329.63,415.3]):
    t=np.arange(int(RATE*.42))/RATE
    x=np.sin(2*np.pi*hz*t)+.19*np.sin(2*np.pi*2*hz*t)*np.exp(-t*12)
    x+=.075*np.sin(2*np.pi*3*hz*t)*np.exp(-t*18)
    x*=env(t,.005,.19)*np.minimum(1,(.42-t)/.04)
    write(f'simon_{i+1}.wav',x,-10)

for name,hz,length in [('ui_focus',740,.055),('ui_valider',540,.11)]:
    t=np.arange(int(RATE*length))/RATE
    x=(np.sin(2*np.pi*hz*t)+.1*noise(t,600,3300))*np.sin(np.pi*t/length)**2
    write(name+'.wav',x,-23)

def periodic_noise(seconds, low, high):
    n=int(seconds*RATE)
    f=np.fft.rfftfreq(n,1/RATE)
    amplitude=np.zeros_like(f)
    select=(f>=low)&(f<=high)
    amplitude[select]=(np.sin(np.pi*(f[select]-low)/(high-low))**.7)/np.maximum(f[select],1)**.65
    spectrum=amplitude*np.exp(1j*rng.uniform(0,2*np.pi,len(f)))
    x=np.fft.irfft(spectrum,n=n)
    return x/max(np.std(x),1e-8)

seconds=16
t=np.arange(int(RATE*seconds))/RATE
for theme in ['eau','organique','machines']:
    stereo=[]
    for side in range(2):
        base=periodic_noise(seconds,65,800)*.10
        if theme=='eau':
            base+=periodic_noise(seconds,450,3900)*(.06+.018*np.sin(2*np.pi*t/8+side))
            base+=np.sin(2*np.pi*99.5*t+np.sin(2*np.pi*t/16)*.1)*.015
        elif theme=='organique':
            pulse=(.5+.5*np.sin(2*np.pi*t/8+side*.15))**2
            base=periodic_noise(seconds,65,520)*(.055+pulse*.06)
            base+=periodic_noise(seconds,650,1900)*pulse*.018
        else:
            base=periodic_noise(seconds,110,2300)*.075
            for hz,level in [(100,.035),(151.5,.015),(301.25,.01)]:
                base+=np.sin(2*np.pi*hz*t+side*.13)*level*(.8+.2*np.sin(2*np.pi*t/16))
        stereo.append(base)
    x=np.stack(stereo,axis=1)
    # Equal endpoint and short boundary smoothing avoid a click at each loop.
    blend=int(RATE*.10)
    join=(x[0]+x[-1])*.5
    for channel in range(2):
        x[:blend,channel]+=np.linspace(1,0,blend)*(join[channel]-x[0,channel])
        x[-blend:,channel]+=np.linspace(0,1,blend)*(join[channel]-x[-1,channel])
    write(f'ambiance_{theme}.ogg',x,-16,loop=True)

(OUT/'BILAN_SONS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(f'{len(report)} original sound assets generated; 44.1 kHz; no clipping.')
