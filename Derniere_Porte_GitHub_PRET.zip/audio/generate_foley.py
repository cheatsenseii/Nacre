"""Original deterministic synthetic footsteps, cloth and landing effects; no samples."""
from pathlib import Path
import wave
import numpy as np

out=Path(__file__).parent
rate=44100
rng=np.random.default_rng(8071)
for name,duration,kind in [('marche_dalle',.24,0),('marche_organique',.3,1),('saut_tissu',.25,2),('reception',.42,3)]:
    t=np.arange(int(rate*duration))/rate
    noise=rng.normal(0,1,len(t))
    smooth=np.convolve(noise,np.ones(12)/12,mode='same')
    if kind==0:
        # Heavy rubber sole: low impact, heel click and a tiny tiled-room tail.
        x=.48*np.sin(2*np.pi*82*t)*np.exp(-t*25)
        x+=.22*np.sin(2*np.pi*168*t)*np.exp(-t*48)+noise*.09*np.exp(-t*62)
        x+=.08*np.sin(2*np.pi*330*t)*np.exp(-t*70)
    elif kind==1:
        # Wet organic floor: bowed low squelch plus a soft suction release.
        x=.40*np.sin(2*np.pi*(92*t-42*t*t))*np.exp(-t*13)+smooth*.42*np.exp(-t*10)
        x+=.15*np.sin(2*np.pi*245*t)*np.exp(-t*28)
    elif kind==2:
        x=smooth*np.sin(np.pi*t/duration)**2*.45
    else:
        x=.5*np.sin(2*np.pi*65*t)*np.exp(-t*13)+noise*.12*np.exp(-t*23)
    x[:110]*=np.linspace(0,1,110);x[-220:]*=np.linspace(1,0,220)
    with wave.open(str(out/(name+'.wav')),'wb') as wav:
        wav.setparams((1,2,rate,0,'NONE','not compressed'))
        wav.writeframes((np.clip(x,-.9,.9)*32767).astype('<i2').tobytes())
    print(name)
