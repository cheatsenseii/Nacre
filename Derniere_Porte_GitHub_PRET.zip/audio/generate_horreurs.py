"""Original offline sound design for the horror-room relay and apparition."""
from pathlib import Path
import wave
import numpy as np

ROOT = Path(__file__).parent
RATE = 44100
rng = np.random.default_rng(7041998)

def save(name, samples, peak=0.7):
    samples = np.tanh(samples)
    samples *= peak / max(0.001, float(np.max(np.abs(samples))))
    fade = min(441, len(samples) // 4)
    samples[:fade] *= np.linspace(0, 1, fade)
    samples[-fade:] *= np.linspace(1, 0, fade)
    with wave.open(str(ROOT / name), 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(RATE)
        wav.writeframes((samples * 32767).astype('<i2').tobytes())

t = np.arange(int(RATE * 1.15)) / RATE
noise = rng.normal(0, 1, len(t))
breath = np.convolve(noise, np.ones(17) / 17, mode='same')
breath -= np.convolve(breath, np.ones(151) / 151, mode='same')
impact = np.sin(2 * np.pi * (69 * t - 13 * t * t)) * np.exp(-9 * t)
metal = sum(np.sin(2 * np.pi * f * t) for f in [317, 491, 719]) * np.exp(-12 * t) * 0.06
gasp = breath * np.exp(-((t - 0.24) / 0.18) ** 2) * 2.4
save('horreurs_sursaut.wav', impact * 0.7 + metal + gasp)

t = np.arange(int(RATE * 0.16)) / RATE
click = rng.normal(0, 1, len(t)) * np.exp(-t * 180)
click += np.sin(2 * np.pi * 1800 * t) * np.exp(-t * 130) * 0.35
save('horreurs_interrupteur.wav', click, 0.55)
print('Two original WAV effects generated, 44.1 kHz / 16 bit.')
