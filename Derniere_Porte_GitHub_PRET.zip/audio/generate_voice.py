"""Generate short character lines using the installed Flite synthetic RMS voice."""
from pathlib import Path
import ctypes, wave, sys
import numpy as np
out=Path(__file__).parent
flite=ctypes.CDLL('libflite.so.1',mode=ctypes.RTLD_GLOBAL)
voice_lib=ctypes.CDLL('libflite_cmu_us_rms.so.1',mode=ctypes.RTLD_GLOBAL)
flite.flite_init()
voice_lib.register_cmu_us_rms.argtypes=[ctypes.c_char_p]
voice_lib.register_cmu_us_rms.restype=ctypes.c_void_p
voice=voice_lib.register_cmu_us_rms(None)
flite.flite_text_to_speech.argtypes=[ctypes.c_char_p,ctypes.c_void_p,ctypes.c_char_p]
flite.flite_text_to_speech.restype=ctypes.c_float
lines={
 'bienvenue':'Bienvenue a Nacre.',
 'prologue':'In nineteen ninety eight, the park closed after an accident. The pools were never drained.',
 'depart':'Okay. Here we go.',
 'arrivee':"Wow, alors ca c'est du champignon!",
 'erreur':"No. That's not it.",
 'victoire':'Oh yes!',
 'mission':'Mission: reach the last door. Start at the waterslide entrance.',
 'mushroom_quest':'Quest: take the stick, defeat the creature, and feed the mushroom.',
 'galleries_quest':'Shut both noisy valves. Then stand still inside the circle for three seconds to open the maze.',
 'labyrinth_quest':'Wake the three vital nodes. Run from the shadow. If it touches you, you die.',
 'combat_quest':'Quest: find the sword, defeat the creatures, and reach the far door.',
 'torture_quest':'Catch Bouptilop. Then load the giant mushroom spores into the tank. Activate three pulses.',
 'horror_quest':'No... What happened to them?',
 'delice':"Quel delice! Cela faisait si longtemps que je n'avais mange d'autre que mes enfants."
}
for name,text in lines.items():
 if len(sys.argv)>1 and name not in sys.argv[1:]:continue
 p=out/('voix_'+name+'.wav')
 flite.flite_text_to_speech(text.encode(),voice,str(p).encode())
 with wave.open(str(p),'rb') as w:
  rate=w.getframerate(); x=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
 # Light saturation and a short quiet room reflection; keep words clear.
 x=np.tanh(x*1.5)
 delay=int(rate*.065)
 y=np.pad(x,(0,delay))
 y[delay:]+=x*.10
 peak=max(float(np.max(np.abs(y))),.001)
 y=y/peak*.65
 fade=min(int(.008*rate),len(y)//2)
 y[:fade]*=np.linspace(0,1,fade); y[-fade:]*=np.linspace(1,0,fade)
 with wave.open(str(p),'wb') as w:
  w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes((y*32767).astype('<i2').tobytes())
 print(name, round(len(y)/rate,2),'s')
