"""Original nonsense line, synthesized locally with the installed Flite RMS voice."""
from pathlib import Path
import ctypes, subprocess, tempfile, wave
import numpy as np

flite=ctypes.CDLL('libflite.so.1',mode=ctypes.RTLD_GLOBAL)
lib=ctypes.CDLL('libflite_cmu_us_rms.so.1',mode=ctypes.RTLD_GLOBAL)
flite.flite_init()
lib.register_cmu_us_rms.argtypes=[ctypes.c_char_p]
lib.register_cmu_us_rms.restype=ctypes.c_void_p
voice=lib.register_cmu_us_rms(None)
flite.flite_text_to_speech.argtypes=[ctypes.c_char_p,ctypes.c_void_p,ctypes.c_char_p]
flite.flite_text_to_speech.restype=ctypes.c_float
chunks=[]
with tempfile.TemporaryDirectory() as folder:
    for i,text in enumerate(['Boop tee lop!', 'La poo', 'Lee!']):
        raw=Path(folder)/f'{i}.wav';out=Path(folder)/f'{i}-fx.wav'
        flite.flite_text_to_speech(text.encode(),voice,str(raw).encode())
        # Stretch the last syllable while preserving its pitch, then raise the voice.
        fx=('atempo=0.5,' if i==2 else '')+'asetrate=20000,aresample=22050'
        subprocess.run(['ffmpeg','-v','error','-y','-i',str(raw),'-af',fx,str(out)],check=True)
        with wave.open(str(out),'rb') as w:
            x=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
        voiced=np.flatnonzero(abs(x)>.018)
        if len(voiced):x=x[max(0,voiced[0]-220):min(len(x),voiced[-1]+350)]
        chunks.extend([x,np.zeros(900 if i==0 else 160)])
x=np.concatenate(chunks);rate=22050
# Slight wobble, saturation and a short quiet echo give the little runner its own voice.
t=np.arange(len(x));warped=t+9*np.sin(t/rate*2*np.pi*7)
x=np.interp(warped,t,x);x=np.tanh(x*1.8)
delay=int(rate*.09);y=np.pad(x,(0,delay));y[delay:]+=x*.16
y*=.72/max(.001,float(np.max(abs(y))))
fade=180;y[:fade]*=np.linspace(0,1,fade);y[-fade:]*=np.linspace(1,0,fade)
dest=Path(__file__).with_name('bouptilop.wav')
with wave.open(str(dest),'wb') as w:
    w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes((y*32767).astype('<i2').tobytes())
print(f'{dest.name}: {len(y)/rate:.2f}s, peak {np.max(abs(y)):.2f}')
