"""Original procedural score: no recordings, third-party loops, or samples."""
from pathlib import Path
import numpy as np
import wave
RATE, SECONDS = 22050, 48
rng = np.random.default_rng(712)
t = np.arange(RATE * SECONDS) / RATE
# Sustained low drones, slow detuning and soft distant bell clusters.
bed = np.zeros_like(t)
for hz, amp, period in [(55, .19, 12), (82.5, .09, 16), (116.54, .045, 24), (56.25, .06, 8)]:
    bed += amp * np.sin(2*np.pi*hz*t + .6*np.sin(2*np.pi*t/period)) * (.75+.25*np.cos(2*np.pi*t/period))
noise = rng.normal(0, 1, len(t))
noise = np.convolve(noise, np.ones(160)/160, mode='same')
bed += noise * .28 * (.65+.35*np.sin(2*np.pi*t/16))
left, right = bed.copy(), bed.copy()
for start, hz, pan in [(3,440,-.6),(10,415.3,.7),(19,622.25,-.4),(29,466.16,.6),(37,392,-.7)]:
    u = t-start
    envelope = np.where(u>=0, (1-np.exp(-np.maximum(u,0)*5))*np.exp(-np.maximum(u,0)/3.2), 0)
    bell = .065*envelope*(np.sin(2*np.pi*hz*u)+.3*np.sin(2*np.pi*hz*2.013*u))
    left += bell*(1-pan)*.5
    right += bell*(1+pan)*.5
    shift=int(.7*RATE)
    echo=np.roll(bell,shift)*.3
    echo[:shift]=0
    left += echo*(1+pan)*.5
    right += echo*(1-pan)*.5
# Quiet breath between repeats, with sample-accurate zero endpoints.
fade=np.minimum(np.minimum(t/2.5,(SECONDS-1/RATE-t)/3),1).clip(0,1)
audio=np.stack([left,right],axis=1)*fade[:,None]
audio=np.tanh(audio)*.72
pcm=(audio*32767).astype('<i2')
output=Path(__file__).with_name('chambre_des_spores.wav')
with wave.open(str(output),'wb') as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(RATE); w.writeframes(pcm.tobytes())
assert np.max(np.abs(audio))<1
print('Original ambience generated:', output.name, 'peak',round(float(np.max(np.abs(audio))),3))
